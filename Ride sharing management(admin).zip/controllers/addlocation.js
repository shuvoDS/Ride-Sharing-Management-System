function isValidLocationForm() {
    const startingPoint = document.getElementById("starting_point").value.trim();
    const destination = document.getElementById("destination").value.trim();

    let isValid = true;

    // Resetting error messages
    document.getElementById('startingPointError').innerHTML = "";
    document.getElementById('destinationError').innerHTML = "";

    // Validating Starting Point
    if (startingPoint === "") {
        document.getElementById('startingPointError').innerHTML = "Starting Point is required";
        isValid = false;
    }

    // Validating Destination
    if (destination === "") {
        document.getElementById('destinationError').innerHTML = "Destination is required";
        isValid = false;
    }

    return isValid;
}