<?php
session_start();
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}
include_once "../models/show_admin_model.php";

$admins = getAdmins(); 

if (!empty($admins)) {
   
    $_SESSION['admins'] = $admins;

  
    header("Location: http://localhost/try/views/show_admin_view.php");
    exit();
} else {
 
    echo "No admins found.";
}
?>
