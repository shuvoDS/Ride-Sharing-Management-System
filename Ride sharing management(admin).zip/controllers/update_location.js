function isValidForm() {
    const startingPoint = document.getElementById("starting_point");
    const destination = document.getElementById("destination");

    let isValid = true;

    // Resetting error messages
    document.getElementById('startingError').innerHTML = "";
    document.getElementById('destinationError').innerHTML = "";

    // Validating Starting Point
    if (startingPoint.value.trim() === "") {
        isValid = false;
        document.getElementById('startingError').innerHTML = "Please fill up the starting point";
    }

    // Validating Destination
    if (destination.value.trim() === "") {
        isValid = false;
        document.getElementById('destinationError').innerHTML = "Please fill up the destination";
    }

    return isValid;
}