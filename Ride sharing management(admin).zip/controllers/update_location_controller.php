<?php
session_start();
include_once "../models/update_location_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}


$selectedLocation = null;
$updateSuccess = false;

$con = mysqli_connect('localhost', 'root', '', 'ridedb');
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    if (isset($_POST['select_location'])) {
        $locationId = isset($_POST['id']) ? (int)$_POST['id'] : null;

        if ($locationId !== null) {
            $selectedLocation = getLocationById($locationId);
            $_SESSION['selectedLocation'] = $selectedLocation;
			header("Location: http://localhost/try/views/update_location_view.php");
            exit();
        }
    }
		if (isset($_POST['delete_location'])) {
				$locationId = isset($_POST['id']) ? (int)$_POST['id'] : null;

				if ($locationId !== null) {
					$deleteMessage= deleteLocation($locationId);
					$_SESSION['deleteMessage']= $deleteMessage;
					$_SESSION['selectedLocation'] =null;
					$_SESSION['updateSuccess'] = true;
					header("Location: http://localhost/try/views/update_location_view.php");
					exit();
				}
		}

    // Check if 'update_driver' button was pressed
    if (isset($_POST['update_location'])) {
        $updatedStartingPoint = test_input($_POST["starting_point"]);
        $updatedDestination = test_input($_POST["destination"]);
       
        $locationId = test_input($_POST["id"]);

        if (empty($updatedStartingPoint) || empty($updatedDestination)) {
            echo "<p class='error'>Please fill in all fields.</p>";
        } else {
            $updateSuccess = updateLocation($updatedStartingPoint, $updatedDestination , $locationId );
            $_SESSION['updateSuccess'] = $updateSuccess;
			unset($_SESSION['selectedLocation']);
			header("Location: http://localhost/try/views/update_location_view.php");
            exit();
        }
    }
}
$locations = getAllLocations();
               
if (!empty($locations)) {
    echo 'Shuvo';
    $_SESSION['locations'] = $locations;
    header("Location: http://localhost/try/views/update_location_view.php");
    exit();
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>
