<?php
session_start();
require_once "../models/add_location_model.php";

$startingPointError = $destinationError = "";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $startingPoint = test_input($_POST['starting_point']);
    $destination = test_input($_POST['destination']);

    if (empty($startingPoint)) {
        $startingPointError = "Starting Point is required";
    }

    if (empty($destination)) {
        $destinationError = "Destination is required";
    }

    if (empty($startingPointError) && empty($destinationError)) {
        $insertSuccess = insertLocation($startingPoint, $destination);

        $_SESSION['successMessage'] = $insertSuccess ? "Location added successfully!" : "Something went wrong while adding the location.";
        if ($insertSuccess) {
            $_SESSION['mapsLink'] = generateGoogleMapsLink($startingPoint, $destination);
        }
    } else {
        $_SESSION['startingPointError'] = $startingPointError;
        $_SESSION['destinationError'] = $destinationError;
    }
}

function generateGoogleMapsLink($startingPoint, $destination) {
    $encodedStartingPoint = urlencode($startingPoint);
    $encodedDestination = urlencode($destination);
    return "https://www.google.com/maps?q=$encodedStartingPoint+to+$encodedDestination";
}

header("Location: ../views/add_location_view.php");
exit();
?>