<?php
// controllers/register_controller.php
include_once "../models/register_model.php";

session_start();
$securityQuestions = [
    "What is your favorite color?" => "",
    "What is your birthplace?" => "",
    "What is your mother's maiden name?" => "",
];

if (!isset($_SESSION['data'])) {
    $_SESSION['data'] = [
        'firstname' => '',
        'lastname' => '',
        'email' => '',
        'securityQuestion' => '',
        'securityAnswer' => '',
        'username' => '',
        'password' => '',
        'confirmpassword' => '',
		
    ];
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['data'] = [
        'firstname' => trim($_POST["firstname"] ?? ''),
        'lastname' => trim($_POST["lastname"] ?? ''),
        'email' => trim($_POST["Email"] ?? ''),
        'securityQuestion' => trim($_POST["securityquestion"] ?? ''),
        'securityAnswer' => trim($_POST['securityanswer'] ?? ''),
        'username' => trim($_POST['username'] ?? ''),
        'password' => trim($_POST['password'] ?? ''),
        'confirmpassword' => trim($_POST['confirmpassword'] ?? ''),
    ];

    $data = $_SESSION['data'];

    foreach ($data as $key => $value) {
        if (empty($value) && $key != 'password' && $key != 'confirmpassword') {
            $errors[] = "Please fill in all fields. Missing: " . ucfirst($key);
        }
    }

    if ($data['password'] !== $data['confirmpassword']) {
        $errors[] = "Password and Confirm Password do not match.";
    }

    if (empty($data['securityQuestion']) || empty($data['securityAnswer'])) {
        $errors[] = "Both Security Question and Answer are required.";
    }

    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please provide a valid email address.";
    }
    
    if (!count($errors) && insertUser($data)) {
         $_SESSION['errors'] = '';
		 $_SESSION['data']='';
        header("Location:../views/home.php");
        exit();
    } else {
        $errors[] = "Registration failed.";
		$_SESSION['errors'] = $errors;
		header("Location: ../views/register_view.php"); 
        exit();
    }
}
  
header("Location: ../views/register_view.php");
exit();

?>
