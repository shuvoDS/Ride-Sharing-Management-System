<?php
session_start();
include_once "../models/update_sm_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}

$selectedManager = null;
$updateSuccess = false;

$con = mysqli_connect('localhost', 'root', '', 'ridedb');
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    if (isset($_POST['select_manager'])) {
        $Id = isset($_POST['id']) ? (int)$_POST['id'] : null;

        if ($Id !== null) {
            $selectedManager = getManagerById($Id);
            $_SESSION['selectedManager'] = $selectedManager;
            header("Location: http://localhost/try/views/update_sm_view.php");
            exit();
        }
    }

    if (isset($_POST['delete_manager'])) {
        $Id = isset($_POST['id']) ? (int)$_POST['id'] : null;

        if ($Id !== null) {
            $deleteMessage = deleteManager($Id);
            $_SESSION['deleteMessage'] = $deleteMessage;
            $_SESSION['selectedManager'] = null;
            $_SESSION['updateSuccess'] = true;
            header("Location: http://localhost/try/views/update_sm_view.php");
            exit();
        }
    }

    // Check if 'update_rider' button was pressed
    if (isset($_POST['update_manager'])) {
    $updatedName = test_input($_POST["name"]);
    $updatedEmail = test_input($_POST["email"]);
    $updatedUsername = test_input($_POST["username"]);
    $Id = test_input($_POST["id"]);
   
    
    // Check for empty fields
    if (empty($updatedName) || empty($updatedEmail) || empty($updatedUsername)) {
        echo "<p class='error'>Please fill in all fields.</p>";
    } else {
        // Call the function to update the rider with new parameters
        $updateSuccess = updateManager($updatedName, $updatedEmail, $updatedUsername,$Id);
		echo $updateSuccess;
        $_SESSION['updateSuccess'] = $updateSuccess;
        unset($_SESSION['selectedManager']);
        header("Location: http://localhost/try/views/update_sm_view.php");
        exit();
    }
    }
}

$managers = getAllManagers();
if (!empty($managers)) {
    $_SESSION['managers'] = $managers;
    header("Location: http://localhost/try/views/update_sm_view.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>