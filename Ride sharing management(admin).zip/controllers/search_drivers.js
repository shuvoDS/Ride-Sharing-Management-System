function search() {
    var input = document.getElementById('searchInput').value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', '../controllers/search_driver_controller.php?search=' + encodeURIComponent(input), true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.querySelector('.driver-table tbody').innerHTML = xhr.responseText;
            document.getElementById('noDataFound').style.display = xhr.responseText.trim() === '' ? 'block' : 'none';
        } else {
            alert('Request failed. Returned status of ' + xhr.status);
        }
    };
    xhr.send();
}