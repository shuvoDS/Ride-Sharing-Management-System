function validate() {
    const username = document.getElementById("Username");
    const securityAnswer = document.getElementById("securityAnswer");

    let flag = true;

    
    document.getElementById('error_username').innerHTML = "";
    document.getElementById('error_securityAnswer').innerHTML = "";

    if (username.value === "") {
        flag = false;
        document.getElementById('error_username').innerHTML = "Please fill up the Username";
    }
    if (securityAnswer.value === "") {
        flag = false;
        document.getElementById('error_securityAnswer').innerHTML = "Please fill up the Security Answer";
    }

    return flag;
}
