function validate() {
    const newPassword = document.getElementById("new_password");
    const confirmPassword = document.getElementById("confirm_password");
 
    let flag = true;
 
    document.getElementById('error_new_password').innerHTML = "";
    document.getElementById('error_confirm_password').innerHTML = "";
 
    if (newPassword.value === "") {
        flag = false;
        document.getElementById('error_new_password').innerHTML = "Please fill up the New Password";
    }
    if (confirmPassword.value === "") {
        flag = false;
        document.getElementById('error_confirm_password').innerHTML = "Please fill up the Confirm Password";
    }
    if (newPassword.value !== "" && confirmPassword.value !== "" && newPassword.value !== confirmPassword.value) {
        flag = false;
        document.getElementById('error_confirm_password').innerHTML = "Passwords do not match";
    }
 
    return flag;
}
