<?php
session_start();
include_once "../models/update_admin_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}

$selectedAdmin = null;
$updateSuccess = false;

$con = mysqli_connect('localhost', 'root', '', 'ridedb');
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    if (isset($_POST['select_admin'])) {
        $adminId = isset($_POST['admin_id']) ? (int)$_POST['admin_id'] : null;

        if ($adminId !== null) {
            $selectedAdmin = getAdminById($adminId);
            $_SESSION['selectedAdmin'] = $selectedAdmin;
            header("Location: http://localhost/try/views/update_admin_view.php");
            exit();
        }
    }

    if (isset($_POST['delete_admin'])) {
        $adminId = isset($_POST['admin_id']) ? (int)$_POST['admin_id'] : null;

        if ($adminId !== null) {
            $deleteMessage = deleteAdmin($adminId);
            $_SESSION['deleteMessage'] = $deleteMessage;
            $_SESSION['selectedAdmin'] = null;
            $_SESSION['updateSuccess'] = true;
            header("Location: http://localhost/try/views/update_admin_view.php");
            exit();
        }
    }

    // Check if 'update_rider' button was pressed
    if (isset($_POST['update_admin'])) {
    $updatedName = test_input($_POST["name"]);
    $updatedEmail = test_input($_POST["email"]);
    $updatedUsername = test_input($_POST["username"]);
    $updatedRole = test_input($_POST["role"]);
   
    $adminId = test_input($_POST["admin_id"]);
   
    
    // Check for empty fields
    if (empty($updatedName) || empty($updatedEmail) || empty($updatedUsername) || empty($updatedRole) ) {
        echo "<p class='error'>Please fill in all fields.</p>";
    } else {
        // Call the function to update the rider with new parameters
        $updateSuccess = updateAdmin($updatedName, $updatedEmail, $updatedUsername, $updatedRole, $adminId);
		echo $updateSuccess;
        $_SESSION['updateSuccess'] = $updateSuccess;
        unset($_SESSION['selectedAdmin']);
        header("Location: http://localhost/try/views/update_admin_view.php");
        exit();
    }
    }
}

$admins = getAllAdmins();
if (!empty($admins)) {
    $_SESSION['admins'] = $admins;
    header("Location: http://localhost/try/views/update_admin_view.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>