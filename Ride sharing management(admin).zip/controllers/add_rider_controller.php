<?php

session_start();
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}

include_once "../models/add_rider_model.php"; // Ensure you have this model file for adding riders

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = isset($_POST["name"]) ? test_input($_POST["name"]) : "";
    $email = isset($_POST["email"]) ? test_input($_POST["email"]) : "";
    $phone = isset($_POST["phone"]) ? test_input($_POST["phone"]) : "";
    $dob = isset($_POST["dob"]) ? test_input($_POST["dob"]) : "";
    $gender = isset($_POST["gender"]) ? test_input($_POST["gender"]) : "";
    $address = isset($_POST["address"]) ? test_input($_POST["address"]) : "";

    // Validate Name
    if (empty($name)) {
        $_SESSION['nameError'] = "Name is required";
    } else {
        $_SESSION['name'] = $name;
    }

    // Validate Email
    if (empty($email)) {
        $_SESSION['emailError'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['emailError'] = "Invalid email format";
    } else {
        $_SESSION['email'] = $email;
    }

    // Validate Phone
    if (empty($phone)) {
        $_SESSION['phoneError'] = "Phone number is required";
    } else {
        $_SESSION['phone'] = $phone;
    }

    // Validate Date of Birth
    if (empty($dob)) {
        $_SESSION['dobError'] = "Date of Birth is required";
    } else {
        $_SESSION['dob'] = $dob;
    }

    // Validate Gender
    if (empty($gender)) {
        $_SESSION['genderError'] = "Gender is required";
    } else {
        $_SESSION['gender'] = $gender;
    }

    // Validate Address
    if (empty($address)) {
        $_SESSION['addressError'] = "Address is required";
    } else {
        $_SESSION['address'] = $address;
    }

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($dob) && !empty($gender) && !empty($address)) {
        $_SESSION['successMessage'] = addRider($name, $email, $phone, $dob, $gender, $address);
		
        if ($_SESSION['successMessage'] === "Rider added successfully!") {
            $_SESSION['nameError'] = $_SESSION['name'] = $_SESSION['emailError'] = $_SESSION['email'] = $_SESSION['phoneError'] = $_SESSION['phone'] =
			$_SESSION['dobError'] = $_SESSION['dob'] = $_SESSION['genderError'] = $_SESSION['gender'] = $_SESSION['addressError'] = $_SESSION['address'] = '';;
        }
    }

    header("Location: ../views/add_rider_view.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>