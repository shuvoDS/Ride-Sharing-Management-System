<?php
session_start();
require_once "../models/forget_password_model.php"; // Assume this contains the check_credentials function

// Initialize or reset session variables
$_SESSION['form_data'] = $_SESSION['form_data'] ?? [];
$_SESSION['messages'] = ['error' => '', 'success' => ''];
$_SESSION['user_data'] = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['Username'] ?? '';
    $securityQuestion = $_POST['securityQuestion'] ?? '';
    $securityAnswer = $_POST['securityAnswer'] ?? '';

    // Store form data in session to repopulate form if necessary
    $_SESSION['form_data'] = $_POST;

    if (empty($username) || empty($securityQuestion) || empty($securityAnswer)) {
        $_SESSION['messages']['error'] = 'Please fill out all fields.';
    } else {
        $user = check_credentials($username, $securityQuestion, $securityAnswer);
        if ($user) {
            $_SESSION['messages']['success'] = 'Match found. Click below to reset your password.';
			$_SESSION['user_data'] = $user; 
            $_SESSION['reset'] = true;
            $_SESSION['username'] = $username;
        } else {
            $_SESSION['messages']['error'] = 'Invalid username, security question, or security answer.';
        }
    }

    // Redirect to the view
    header('Location: ../views/forget_password_view.php');
    exit();
}
?>
