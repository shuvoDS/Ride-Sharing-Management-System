<?php
session_start();
session_destroy();
$_SESSION = array();

// After clearing the session, redirect to the view
header("Location: ../views/logout_view.php");
exit();
?>
