<?php
session_start();

include_once "../models/profile_update_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}

$_SESSION['message'] = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $currentEmail = $_POST['currentEmail'];
    $newEmail = $_POST['newEmail'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
	
	$_SESSION['currentEmail']=$currentEmail;
	$_SESSION['newEmail']=$newEmail;
	$_SESSION['FirstName']=$firstName;
	$_SESSION['LastName']=$lastName;

    if (empty($currentEmail)) {
        $_SESSION['message'] .= "Current Email is required. ";
    }
    if (empty($newEmail)) {
        $_SESSION['message'] .= "New Email is required. ";
    }
    if (empty($firstName)) {
        $_SESSION['message'] .= "First Name is required. ";
    }
    if (empty($lastName)) {
        $_SESSION['message'] .= "Last Name is required. ";
    }

    if ($_SESSION['message'] !== '') {
        header("Location:../views/profile_update_view.php");
        exit();
    }

    if (updateProfile($currentEmail, $newEmail, $firstName, $lastName)) {
        $user = check_user_credentials($newEmail);
        if ($user) {
            $_SESSION['adminLogin'] = true;
            $_SESSION['Email'] = $newEmail; // Update session email to new email
            $_SESSION['firstName'] = $user['firstname'];
            $_SESSION['lastName'] = $user['lastname'];
            $_SESSION['message'] = "Profile updated successfully!";
            header("Location:../views/profile_update_view.php");
            exit();
        } else {
            $_SESSION['message'] = "Failed to retrieve updated profile.";
            header("Location:../views/profile_update_view.php");
            exit();
        }
    } else {
        $_SESSION['message'] = "Failed to update profile.";
        header("Location:../views/profile_update_view.php");
        exit();
    }
}
?>
