<?php
session_start();

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}

// Assuming admin login is validated
function sanitize_data($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Store sanitized data in session to use in the view
$_SESSION['profileData'] = [
    'email' => isset($_SESSION['Email']) ? sanitize_data($_SESSION['Email']) : 'No Email Provided',
    'firstName' => isset($_SESSION['firstName']) ? sanitize_data($_SESSION['firstName']) : 'No First Name Provided',
    'lastName' => isset($_SESSION['lastName']) ? sanitize_data($_SESSION['lastName']) : 'No Last Name Provided'
];

// Redirect to the profile view
header("Location: ../views/profile_view.php");
exit();
?>
