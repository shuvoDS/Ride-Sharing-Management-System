function isValidForm() {
    const currentPassword = document.getElementById("currentPassword");
    const newPassword = document.getElementById("newPassword");
    const confirmPassword = document.getElementById("confirmPassword");
    
    let isValid = true;
    
    
    document.getElementById('error_currentPassword').innerHTML = "";
    document.getElementById('error_newPassword').innerHTML = "";
    document.getElementById('error_confirmPassword').innerHTML = "";

   
    if (currentPassword.value === "") {
        isValid = false;
        document.getElementById('error_currentPassword').innerHTML = "Please fill up the Current Password";
    }
    
    
    if (newPassword.value === "") {
        isValid = false;
        document.getElementById('error_newPassword').innerHTML = "Please fill up the New Password";
    }
    
    
    if (confirmPassword.value === "") {
        isValid = false;
        document.getElementById('error_confirmPassword').innerHTML = "Please fill up the Confirm Password";
    } 
	if (newPassword.value !== "" && confirmPassword.value !== "" && newPassword.value !== confirmPassword.value) {
        isValid = false;
        document.getElementById('error_confirmPassword').innerHTML = "Passwords do not match";
    }
    
    return isValid;
}
