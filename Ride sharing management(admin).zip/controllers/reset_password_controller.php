<?php
session_start();

include_once "../models/reset_password_model.php";

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_SESSION['username'];
	
    $newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';
	
    $confirmPassword = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if ($newPassword !== $confirmPassword) {
        $_SESSION['error'] = 'Passwords do not match.';
    } else {
        $success = resetPassword($username, $newPassword);
        if ($success) {
            $_SESSION['successMessage'] = 'Password changed successfully. Click below to login.';
            unset($_SESSION['reset']);
            unset($_SESSION['username']);
        } else {
            $_SESSION['error'] = 'Failed to change password.';
        }
    }
}




header("Location:../views/reset_password_view.php");
exit();
?>

