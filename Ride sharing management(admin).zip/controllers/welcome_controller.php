<?php
session_start();

// Perform the session check and redirect if the user is not logged in
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}

function sanitize_input($input) {
    return filter_var(trim(strip_tags($input)), FILTER_SANITIZE_STRING);
}

// Store sanitized data in session to use in the view
$_SESSION['displayFirstName'] = isset($_SESSION['firstName']) ? sanitize_input($_SESSION['firstName']) : '';
$_SESSION['displayLastName'] = isset($_SESSION['lastName']) ? sanitize_input($_SESSION['lastName']) : '';

// Redirect to the welcome view
header("Location: ../views/welcome_view.php");
exit();
?>
