<?php


include_once "../models/login_model.php";

session_start();

function sanitize_input($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize_input($_POST['email']);
    $password = sanitize_input($_POST['password']);
	$_SESSION['email'] = $email;
	$_SESSION['password'] = $password;
	 

    if (empty($email) || empty($password)) {
        $_SESSION['emailErr'] = empty($email) ? "Email is required" : '';
        $_SESSION['passwordErr'] = empty($password) ? "Password is required" : '';
        header("Location: ../views/login_view.php");
        exit();
    } else {
		
		$_SESSION['emailErr'] ='';
		$_SESSION['passwordErr'] = '';
        $user = check_user_credentials($email, $password);

        if ($user) {
			$_SESSION['email'] = '';
	        $_SESSION['password'] ='';
			$_SESSION['Error'] = '';
            $_SESSION['adminLogin'] = true;
            $_SESSION['Email'] = $email;
            $_SESSION['firstName'] = $user['firstname'];
            $_SESSION['lastName'] = $user['lastname'];
			
			if (isset($_POST['rememberMe'])) {
                setcookie('emailid', $email, time() + 86400,"/"); // 1 day
                setcookie('password', $password, time() + 86400,"/"); // 1 day
				
            }

            header('Location: ../controllers/welcome_controller.php');
            exit();
        } else {
            $_SESSION['Error'] = "Invalid email or password";
          
            header("Location: ../views/login_view.php");
            exit();
        }
    }
} else {
    header("Location: ../views/login_view.php");
    exit();
}
?>
