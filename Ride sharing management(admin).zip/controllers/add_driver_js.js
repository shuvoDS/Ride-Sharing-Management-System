function validate() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const license = document.getElementById("license");
    let flag = true;
	document.getElementById('name').innerHTML = "";
    document.getElementById('email').innerHTML = "";
    document.getElementById('license').innerHTML = "";

    if (name.value === "") {
        flag = false;
        document.getElementById('nameError').innerHTML = "Please fill up the name";
    }

    if (email.value === "") {
        flag = false;
        document.getElementById('emailError').innerHTML = "Please fill up the email";
    }

    if (license.value === "") {
        flag = false;
        document.getElementById('licenseError').innerHTML = "Please fill up the license number";
    }

    return flag;
}
