<?php
session_start();
include_once "../models/show_earnings_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

$_SESSION['earnings'] = getTotalEarningsPerDriver();

header("Location: http://localhost/try/views/show_earnings_view.php");
exit();
?>