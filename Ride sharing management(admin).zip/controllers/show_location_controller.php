<?php
session_start();

require_once "../models/show_location_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

$locations = getLocations();
$_SESSION['locations'] = $locations;

// Redirect to the view
header("Location: ../views/show_location_view.php");
exit();
?>
