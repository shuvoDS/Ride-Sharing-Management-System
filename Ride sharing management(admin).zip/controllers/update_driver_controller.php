<?php
session_start();
include_once "../models/update_driver_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}


$selectedDriver = null;
$updateSuccess = false;

$con = mysqli_connect('localhost', 'root', '', 'ridedb');
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if 'select_driver' button was pressed
    if (isset($_POST['select_driver'])) {
        $driverId = isset($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;

        if ($driverId !== null) {
            $selectedDriver = getDriverById($driverId);
            $_SESSION['selectedDriver'] = $selectedDriver;
			header("Location: http://localhost/try/views/update_driver_views.php");
            exit();
        }
    }
		if (isset($_POST['delete_driver'])) {
				$driverId = isset($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;

				if ($driverId !== null) {
					$deleteMessage= deleteDriver($driverId);
					$_SESSION['deleteMessage']= $deleteMessage;
					$_SESSION['selectedDriver'] =null;
					$_SESSION['updateSuccess'] = true;
					header("Location: http://localhost/try/views/update_driver_views.php");
					exit();
				}
		}

    // Check if 'update_driver' button was pressed
    if (isset($_POST['update_driver'])) {
        $updatedName = test_input($_POST["name"]);
        $updatedEmail = test_input($_POST["email"]);
        $updatedLicense = test_input($_POST["license"]);
        $driverId = test_input($_POST["driver_id"]);

        if (empty($updatedName) || empty($updatedEmail) || empty($updatedLicense)) {
            echo "<p class='error'>Please fill in all fields.</p>";
        } else {
            $updateSuccess = updateDriver($updatedName, $updatedEmail, $updatedLicense, $driverId);
            $_SESSION['updateSuccess'] = $updateSuccess;
			unset($_SESSION['selectedDriver']);
			header("Location: http://localhost/try/views/update_driver_views.php");
            exit();
        }
    }
}
$drivers = getAllDrivers();
if (!empty($drivers)) {
    
    $_SESSION['drivers'] = $drivers;
    header("Location: http://localhost/try/views/update_driver_views.php");
    exit();
}
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>
