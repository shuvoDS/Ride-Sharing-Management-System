function isValidForm() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const license = document.getElementById("license");
    
    let isValid = true;
    
    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('licenseError').innerHTML = "";

    if (name.value === "") {
        isValid = false;
        document.getElementById('nameError').innerHTML = "Please fill up the name";
    }

    if (email.value === "") {
        isValid = false;
        document.getElementById('emailError').innerHTML = "Please fill up the email";
    }

    if (license.value === "") {
        isValid = false;
        document.getElementById('licenseError').innerHTML = "Please fill up the license number";
    }

    return isValid;
}
