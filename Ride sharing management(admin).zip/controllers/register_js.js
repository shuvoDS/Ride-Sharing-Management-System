function validate() {
    const firstname = document.getElementById("firstname");
    const lastname = document.getElementById("lastname");
    const securityquestion = document.getElementById("securityquestion");
    const securityanswer = document.getElementById("securityanswer");
    const email = document.getElementById("Email");
    const username = document.getElementById("username");
    const password = document.getElementById("password");
    const confirmpassword = document.getElementById("confirmpassword");
    let flag = true;

    
    document.getElementById('error_firstname').innerHTML = "";
    document.getElementById('error_lastname').innerHTML = "";
    document.getElementById('error_securityquestion').innerHTML = "";
    document.getElementById('error_securityanswer').innerHTML = "";
    document.getElementById('error_email').innerHTML = "";
    document.getElementById('error_username').innerHTML = "";
    document.getElementById('error_password').innerHTML = "";
    document.getElementById('error_confirmpassword').innerHTML = "";

    if (firstname.value === "") {
        flag = false;
        document.getElementById('error_firstname').innerHTML = "Please fill up the First Name";
    }
    if (lastname.value === "") {
        flag = false;
        document.getElementById('error_lastname').innerHTML = "Please fill up the Last Name";
    }
    if (securityquestion.value === "") {
        flag = false;
        document.getElementById('error_securityquestion').innerHTML = "Please select a Security Question";
    }
    if (securityanswer.value === "") {
        flag = false;
        document.getElementById('error_securityanswer').innerHTML = "Please fill up the Security Answer";
    }
    if (email.value === "") {
        flag = false;
        document.getElementById('error_email').innerHTML = "Please fill up the Email";
    }
    if (username.value === "") {
        flag = false;
        document.getElementById('error_username').innerHTML = "Please fill up the Username";
    }
    if (password.value === "") {
        flag = false;
        document.getElementById('error_password').innerHTML = "Please fill up the Password";
    }
    if (confirmpassword.value === "") {
        flag = false;
        document.getElementById('error_confirmpassword').innerHTML = "Please fill up the Confirm Password";
    }
	 if (password.value !== "" && confirmpassword.value !== "" && password.value !== confirmpassword.value) {
        flag = false;
        document.getElementById('error_confirmpassword').innerHTML = "Passwords do not match";
    }
 

    return flag;
}
