<?php
session_start();
include_once "../models/show_driver_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}
$_SESSION['drivers'] = getdrivers();

header("Location: http://localhost/try/views/show_driver_view.php");
exit();
?>