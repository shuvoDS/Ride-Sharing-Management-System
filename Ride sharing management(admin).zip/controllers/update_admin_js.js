function isValidForm() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const username = document.getElementById("username");
    const role = document.getElementById("role");

    let isValid = true;

    // Resetting error messages
    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('usernameError').innerHTML = "";
    document.getElementById('roleError').innerHTML = "";
  

    // Validating Name
    if (name.value.trim() === "") {
        isValid = false;
        document.getElementById('nameError').innerHTML = "Please fill up the name";
    }

    // Validating Email
    if (email.value.trim() === "") {
        isValid = false;
        document.getElementById('emailError').innerHTML = "Please fill up the email";
    } else if (!/^\S+@\S+\.\S+$/.test(email.value)) {
        isValid = false;
        document.getElementById('emailError').innerHTML = "Please enter a valid email address";
    }

    // Validating Username
    if (username.value.trim() === "") {
        isValid = false;
        document.getElementById('usernameError').innerHTML = "Please fill up the username";
    }

    // Validating Role
    if (role.value === "") {
        isValid = false;
        document.getElementById('roleError').innerHTML = "Please select a role";
    }

   

    return isValid;
}