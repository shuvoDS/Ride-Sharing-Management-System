function validate() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const username = document.getElementById("username");
    const password = document.getElementById("password");
    let flag = true;

    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('usernameError').innerHTML = "";
    document.getElementById('passwordError').innerHTML = "";

    if (name.value === "") {
        flag = false;
        document.getElementById('nameError').innerHTML = "Please fill up the name";
    }

    if (email.value === "") {
        flag = false;
        document.getElementById('emailError').innerHTML = "Please fill up the email";
    }

    if (username.value === "") {
        flag = false;
        document.getElementById('usernameError').innerHTML = "Please fill up the username";
    }

    if (password.value === "") {
        flag = false;
        document.getElementById('passwordError').innerHTML = "Please fill up the password";
    }

    return flag;
}
