function isValidForm() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const dob = document.getElementById("dob");
    const gender = document.getElementById("gender");
    const address = document.getElementById("address");

    let isValid = true;

    // Resetting error messages
    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('phoneError').innerHTML = "";
    document.getElementById('dobError').innerHTML = "";
    document.getElementById('genderError').innerHTML = "";
    document.getElementById('addressError').innerHTML = "";

    // Validating Name
    if (name.value.trim() === "") {
        isValid = false;
        document.getElementById('nameError').innerHTML = "Please fill up the name";
    }

    // Validating Email
    if (email.value.trim() === "") {
        isValid = false;
        document.getElementById('emailError').innerHTML = "Please fill up the email";
    } else if (!/^\S+@\S+\.\S+$/.test(email.value)) {
        isValid = false;
        document.getElementById('emailError').innerHTML = "Please enter a valid email address";
    }

    // Validating Phone
    if (phone.value.trim() === "") {
        isValid = false;
        document.getElementById('phoneError').innerHTML = "Please fill up the phone number";
    } else if (!/^\d+$/.test(phone.value)) {
        isValid = false;
        document.getElementById('phoneError').innerHTML = "Phone number should only contain digits";
    }

    // Validating Date of Birth
    if (dob.value.trim() === "") {
        isValid = false;
        document.getElementById('dobError').innerHTML = "Please fill up the date of birth";
    }

    // Validating Address
    if (address.value.trim() === "") {
        isValid = false;
        document.getElementById('addressError').innerHTML = "Please fill up the address";
    }

    return isValid;
}