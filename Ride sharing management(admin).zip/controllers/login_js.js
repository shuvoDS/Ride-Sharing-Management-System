function validate() {
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    let flag = true;

   
    document.getElementById('error_email').innerHTML = "";
    document.getElementById('error_password').innerHTML = "";

    if (email.value === "") {
        flag = false;
        document.getElementById('error_email').innerHTML = "Please fill up the Email";
    }
    if (password.value === "") {
        flag = false;
        document.getElementById('error_password').innerHTML = "Please fill up the Password";
    }
    return flag;
}
