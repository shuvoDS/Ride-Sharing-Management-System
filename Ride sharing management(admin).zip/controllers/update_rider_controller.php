<?php
session_start();
include_once "../models/update_rider_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location:../views/login_view.php");
    exit();
}

$selectedRider = null;
$updateSuccess = false;

$con = mysqli_connect('localhost', 'root', '', 'ridedb');
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if 'select_rider' button was pressed
    if (isset($_POST['select_rider'])) {
        $riderId = isset($_POST['rider_id']) ? (int)$_POST['rider_id'] : null;

        if ($riderId !== null) {
            $selectedRider = getRiderById($riderId);
            $_SESSION['selectedRider'] = $selectedRider;
            header("Location: http://localhost/try/views/update_rider_views.php");
            exit();
        }
    }

    if (isset($_POST['delete_rider'])) {
        $riderId = isset($_POST['rider_id']) ? (int)$_POST['rider_id'] : null;

        if ($riderId !== null) {
            $deleteMessage = deleteRider($riderId);
            $_SESSION['deleteMessage'] = $deleteMessage;
            $_SESSION['selectedRider'] = null;
            $_SESSION['updateSuccess'] = true;
            header("Location: http://localhost/try/views/update_rider_views.php");
            exit();
        }
    }

    // Check if 'update_rider' button was pressed
    if (isset($_POST['update_rider'])) {
    $updatedName = test_input($_POST["name"]);
    $updatedEmail = test_input($_POST["email"]);
    $updatedPhone = test_input($_POST["phone"]);
    $updatedDob = test_input($_POST["dob"]);
    $updatedGender = test_input($_POST["gender"]);
    $updatedAddress = test_input($_POST["address"]);
    $riderId = test_input($_POST["rider_id"]);

    // Check for empty fields
    if (empty($updatedName) || empty($updatedEmail) || empty($updatedPhone) || empty($updatedDob) || empty($updatedGender) || empty($updatedAddress)) {
        echo "<p class='error'>Please fill in all fields.</p>";
    } else {
        // Call the function to update the rider with new parameters
        $updateSuccess = updateRider($updatedName, $updatedEmail, $updatedPhone, $updatedDob, $updatedGender, $updatedAddress, $riderId);
        $_SESSION['updateSuccess'] = $updateSuccess;
        unset($_SESSION['selectedRider']);
        header("Location: http://localhost/try/views/update_rider_views.php");
        exit();
    }
    }
}

$riders = getAllRiders();
if (!empty($riders)) {
    $_SESSION['riders'] = $riders;
    header("Location: http://localhost/try/views/update_rider_views.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>