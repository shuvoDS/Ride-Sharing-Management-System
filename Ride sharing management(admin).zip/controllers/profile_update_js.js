function validate() {
    const currentEmail = document.getElementsByName("currentEmail");
    const newEmail = document.getElementsByName("newEmail");
    const firstName = document.getElementsByName("firstName");
    const lastName = document.getElementsByName("lastName");

    let isValid = true;

    document.getElementById('error_currentEmail').innerHTML = "";
    document.getElementById('error_newEmail').innerHTML = "";
    document.getElementById('error_firstName').innerHTML = "";
    document.getElementById('error_lastName').innerHTML = "";

    if (currentEmail[0].value === "") {
        isValid = false;
        document.getElementById('error_currentEmail').innerHTML = "Please fill up the Current Email";
    }
    if (newEmail[0].value === "") {
        isValid = false;
        document.getElementById('error_newEmail').innerHTML = "Please fill up the New Email";
    }
    if (firstName[0].value === "") {
        isValid = false;
        document.getElementById('error_firstName').innerHTML = "Please fill up the First Name";
    }
    if (lastName[0].value === "") {
        isValid = false;
        document.getElementById('error_lastName').innerHTML = "Please fill up the Last Name";
    }

    return isValid;
}
