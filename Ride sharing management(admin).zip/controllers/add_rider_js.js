function validate() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const dob = document.getElementById("dob");
    const gender = document.getElementById("gender");
    const address = document.getElementById("address");

   
    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('phoneError').innerHTML = "";
    document.getElementById('dobError').innerHTML = "";
    document.getElementById('genderError').innerHTML = "";
    document.getElementById('addressError').innerHTML = "";

    let flag = true;

    if (name.value.trim() === "") {
        flag = false;
        document.getElementById('nameError').innerText = "Please fill up the name";
    }

    if (email.value.trim() === "") {
        flag = false;
        document.getElementById('emailError').innerText = "Please fill up the email";
    }

    if (phone.value.trim() === "") {
        flag = false;
        document.getElementById('phoneError').innerText = "Please fill up the phone number";
    }

    if (dob.value.trim() === "") {
        flag = false;
        document.getElementById('dobError').innerText = "Please fill up the date of birth";
    }

    if (gender.value.trim() === "") {
        flag = false;
        document.getElementById('genderError').innerText = "Please select a gender";
    }

    if (address.value.trim() === "") {
        flag = false;
        document.getElementById('addressError').innerText = "Please fill up the address";
    }

    return flag;
}