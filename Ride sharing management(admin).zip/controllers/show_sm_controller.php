<?php
session_start();
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}
include_once "../models/show_sm_model.php";

$managers = getManagers(); 

if (!empty($managers)) {
   
    $_SESSION['managers'] = $managers;

  
    header("Location: http://localhost/try/views/show_sm_view.php");
    exit();
} else {
 
    echo "No managers found.";
}
?>
