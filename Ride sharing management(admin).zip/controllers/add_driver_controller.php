<?php

session_start();
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}
include_once "../models/add_driver_models.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    

    $name = isset($_POST["name"]) ? test_input($_POST["name"]) : "";
    $email = isset($_POST["email"]) ? test_input($_POST["email"]) : "";
    $license = isset($_POST["license"]) ? test_input($_POST["license"]) : "";
	
	

    if (empty($name)) {
        $_SESSION['nameError'] = "Name is required";
    } else {
        $_SESSION['name'] = $name;
    }

    if (empty($email)) {
        $_SESSION['emailError'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['emailError'] = "Invalid email format";
    } else {
        $_SESSION['email'] = $email;
    }

    if (empty($license)) {
        $_SESSION['licenseError'] = "License Number is required";
    } else {
        $_SESSION['license'] = $license;
    }

    if (!empty($name) && !empty($email) && !empty($license)) {
        $_SESSION['successMessage'] = addDriver($name, $email, $license);
		
		if ($_SESSION['successMessage'] === "Driver added successfully!") {
            $_SESSION['nameError'] = $_SESSION['name'] = $_SESSION['emailError'] = $_SESSION['email'] = $_SESSION['licenseError'] = $_SESSION['license'] = '';
        }
    }

    header("Location:../views/add_driver_view.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
