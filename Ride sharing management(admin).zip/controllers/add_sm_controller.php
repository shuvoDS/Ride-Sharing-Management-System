<?php
session_start();
if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}
include_once "../models/add_sm_model.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST["name"]) ? test_input($_POST["name"]) : "";
    $email = isset($_POST["email"]) ? test_input($_POST["email"]) : "";
    $username = isset($_POST["username"]) ? test_input($_POST["username"]) : "";
    $password = isset($_POST["password"]) ? test_input($_POST["password"]) : "";
   
    if (empty($name)) {
        $_SESSION['nameError'] = "Name is required";
    } else {
        $_SESSION['name'] = $name;
    }

    if (empty($email)) {
        $_SESSION['emailError'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['emailError'] = "Invalid email format";
    } else {
        $_SESSION['email'] = $email;
    }

    if (empty($username)) {
        $_SESSION['usernameError'] = "Username is required";
    } else {
        $_SESSION['username'] = $username;
    }

    if (empty($password)) {
        $_SESSION['passwordError'] = "Password is required";
    }
	else {
        $_SESSION['password'] = $password;
    }

    if (!empty($name) && !empty($email) && !empty($username) && !empty($password)) {
        $_SESSION['successMessage'] = supportmanager($name, $email, $username, $password);

        if ($_SESSION['successMessage'] === "Manager added successfully!") {
            $_SESSION['nameError'] = $_SESSION['name'] = $_SESSION['emailError'] = $_SESSION['email'] = $_SESSION['usernameError'] = $_SESSION['username'] = $_SESSION['password']=$_SESSION['passwordError'] = '';
        }
    }

    header("Location:../views/add_sm_view.php");
    exit();
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
