<?php
session_start();
require_once "../models/change_password_model.php";

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['changePassword'])) {
    $currentPassword = isset($_POST['currentPassword']) ? $_POST['currentPassword'] : null;
    $newPassword = isset($_POST['newPassword']) ? $_POST['newPassword'] : null;
    $confirmPassword = isset($_POST['confirmPassword']) ? $_POST['confirmPassword'] : null;
    $email = isset($_SESSION['Email']) ? $_SESSION['Email'] : '';
	
	$_SESSION['currentPassword'] = $currentPassword;
	$_SESSION['newPassword'] = $newPassword;
	$_SESSION['confirmPassword'] = $confirmPassword;

    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $_SESSION['passwordChangeError'] = "All fields are required.";
        if (empty($currentPassword)) $_SESSION['passwordChangeError'] .= " Current password is required.";
        if (empty($newPassword)) $_SESSION['passwordChangeError'] .= " New password is required.";
        if (empty($confirmPassword)) $_SESSION['passwordChangeError'] .= " Confirm password is required.";
        header("Location:../views/change_password_view.php");
        exit();
    }

    $con = connectToDatabase();
    $result = getUserByEmail($con, $email);
    if (!$result) {
        $_SESSION['passwordChangeError'] = "Database error: " . mysqli_error($con);
        header("Location:../views/change_password_view.php");
        exit();
    }

    $row = mysqli_fetch_assoc($result);
    if ($result && $row)
	 {
		 $_SESSION['currentPassword'] = '';
	     $_SESSION['newPassword'] = '';
	     $_SESSION['confirmPassword'] = '';
		 $_SESSION['passwordChangeError']='';
		 
	 }
    if (!$row) {
        $_SESSION['passwordChangeError'] = "User not found in the database";
    } elseif ($currentPassword !== $row['password']) {
        $_SESSION['passwordChangeError'] = "Current password is incorrect";
    } elseif ($newPassword !== $confirmPassword) {
        $_SESSION['passwordChangeError'] = "New password and confirm password do not match";
    } else {
        if (!updatePassword($con, $newPassword, $email)) {
            $_SESSION['passwordChangeError'] = "Password change failed";
        } else {
            $_SESSION['passwordChangeSuccess'] = "Password changed successfully. <a href='../views/login_view.php'>Click here to login</a>";
            header("Location:../views/change_password_view.php");
            exit();
        }
    }
	 
	
}

require_once "../views/change_password_view.php";
?>
