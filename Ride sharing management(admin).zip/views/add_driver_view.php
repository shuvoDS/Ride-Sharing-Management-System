<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Driver</title>
    <link rel="stylesheet" type="text/css" href="../views/adddriver.css">
   <script src="../controllers/add_driver_js.js"></script> 
</head>

<body>
    <div class="container">
        <h1>Add Driver</h1>

        <form action="../controllers/add_driver_controller.php" method="post" onsubmit="return validate()" novalidate>
            <fieldset>
                <legend>Driver Information</legend>
                <table>
                    <tr>
                        <td><label for="name">Name:</label></td>
                        <td><input type="text" id="name" name="name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>"></td>
                        <td><span class="error" id="nameError">
                                <?php echo isset($_SESSION['nameError']) ? $_SESSION['nameError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" id="email" name="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>"></td>
                        <td><span class="error" id="emailError">
                                <?php echo isset($_SESSION['emailError']) ? $_SESSION['emailError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="license">License Number:</label></td>
                        <td><input type="text" id="license" name="license" value="<?php echo isset($_SESSION['license']) ? $_SESSION['license'] : ''; ?>"></td>
                        <td><span class="error" id="licenseError">
                                <?php echo isset($_SESSION['licenseError']) ? $_SESSION['licenseError'] : ''; ?>
                            </span></td>
                    </tr>
                </table>
            </fieldset>
            <br>
            <input type="submit" value="Add Driver">

        </form>

        <?php
        if (isset($_SESSION['successMessage']) && !empty($_SESSION['successMessage'])) {
            echo "<p class='success'>{$_SESSION['successMessage']}</p>";
            unset($_SESSION['successMessage']);
        }
        ?>
        <br>
        <a href="../controllers/show_driver_controller.php">Show Drivers</a>
        <br>
        <br>
        <a href="../views/dashboard.php">Back to Admin Dashboard</a>
    </div>
</body>

</html>
