<?php

include_once "../views/header1.php"; 


if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['earnings'])) {
    echo "No earnings data to display.";
    exit();
}

$earningsData = $_SESSION['earnings'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Yearly Earnings</title>
	<link rel="stylesheet" type="text/css" href="show_earnings.css">
</head>
<body>
    <h1>Total Yearly Earnings</h1>
    <table border="1">
        <tr>
            <th>Driver ID</th>
			 <th>Name</th>
            <th>Year</th>
            <th>Total Earnings</th>
        </tr>
        <?php foreach ($earningsData as $earning): ?>
            <tr>
                <td><?= htmlspecialchars($earning['driver_id']) ?></td>
				<td><?= htmlspecialchars($earning['name']) ?></td>
                <td><?= htmlspecialchars($earning['year']) ?></td>
                <td><?= htmlspecialchars($earning['total_earnings']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
	 <p><a href="../views/dashboard.php">Back to Admin Dashboard</a></p>
</body>
</html>