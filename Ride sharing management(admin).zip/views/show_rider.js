function getData() {
    const name = document.getElementById("name").value;
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        let data = JSON.parse(this.responseText);

        
        const displayElement = document.getElementById("i1");

        if (data.length > 0) {
            
            let table = "<table border='1'><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>DOB</th><th>Gender</th><th>Address</th></tr>";

           
            data.forEach(function(item) {
                table += "<tr>";
                table += "<td>" + item.rider_id + "</td>";
                table += "<td>" + item.name + "</td>";
                table += "<td>" + item.email + "</td>";
                table += "<td>" + item.phone + "</td>";
				table += "<td>" + item.dob + "</td>";
				table += "<td>" + item.gender + "</td>";
				table += "<td>" + item.address + "</td>";
                table += "</tr>";
            });

            table += "</table>";
            
            displayElement.innerHTML = table;
        } else {
          
            displayElement.innerHTML = "Rider not found";
        }
    };

    xhttp.open("POST", "http://localhost/try/models/show_rider_model_ajax.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("searchKey=" + encodeURIComponent(name));
    return false;
}