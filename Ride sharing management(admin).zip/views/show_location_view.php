<?php
include_once "../views/header1.php";


if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: login.php");
    exit();
}

$locations = $_SESSION['locations'] ?? [];
function generateGoogleMapsLink($startingPoint, $destination) {
    $encodedStartingPoint = urlencode($startingPoint);
    $encodedDestination = urlencode($destination);
    return "https://www.google.com/maps?q=$encodedStartingPoint+to+$encodedDestination";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Locations</title>
    <link rel="stylesheet" type="text/css" href="../views/show_locations.css">
</head>
<body>
<div class="container">
    <h1>Show Locations</h1>
    <table class="location-table">
        <tr>
            <th>Location ID</th>
            <th>Starting Point</th>
            <th>Destination</th>
            <th>View Route on Google Maps</th>
        </tr>
        <?php foreach ($locations as $location): ?>
            <tr>
                <td><?= $location['id']; ?></td>
                <td><?= $location['starting_point']; ?></td>
                <td><?= $location['destination']; ?></td>
                <td>
                    <a href="<?= generateGoogleMapsLink($location['starting_point'], $location['destination']); ?>" target="_blank">View Route</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <p><a href="../views/dashboard.php">Back to Admin Dashboard</a></p>
</div>
</body>
</html>

<?php
include_once "../views/footer.php";
unset($_SESSION['locations']); // clean up session data
?>