<?php include_once "../views/header.php"; 
session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="change_password.css">
	<script src="../controllers/change_password_js.js"></script> 
</head>
<body>
    <div class="container">
        <h1>Change Password</h1>
        <form id="changePasswordForm" action="../controllers/change_password_controller.php" method="post" novalidate onsubmit="return isValidForm();">
            <fieldset>
                <legend>Change Password</legend>
                <table>
                    <tr>
                        <td><label for="currentPassword">Current Password:</label></td>
                        <td><input type="password" id="currentPassword" name="currentPassword" value="<?php echo isset($_SESSION['currentPassword']) ? htmlspecialchars($_SESSION['currentPassword']) : ''; ?>"></td>
                    </tr>
                    <tr><td colspan="2" class="error" id="error_currentPassword"></td></tr>
                    <tr>
                        <td><label for="newPassword">New Password:</label></td>
                        <td><input type="password" id="newPassword" name="newPassword"></td>
                    </tr>
                    <tr><td colspan="2" class="error" id="error_newPassword"></td></tr>
                    <tr>
                        <td><label for="confirmPassword">Confirm Password:</label></td>
                        <td><input type="password" id="confirmPassword" name="confirmPassword"></td>
                    </tr>
                    <tr><td colspan="2" class="error" id="error_confirmPassword"></td></tr>
                </table>
            </fieldset>
            <br>
            <input type="submit" name="changePassword" value="Change Password">
        </form>
        <?php
        if (isset($_SESSION['passwordChangeError'])) {
            echo '<div class="error">' . $_SESSION['passwordChangeError'] . '</div>';
            unset($_SESSION['passwordChangeError']);
        }
        if (isset($_SESSION['passwordChangeSuccess'])) {
            echo '<div class="success">' . $_SESSION['passwordChangeSuccess'] . '</div>';
            unset($_SESSION['passwordChangeSuccess']);
        }
        ?>
    </div>
</body>
</html>

<?php include_once "../views/footer.php"; ?>
