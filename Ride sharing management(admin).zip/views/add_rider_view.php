<?php
include_once "../views/header1.php"; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Rider</title>
    <link rel="stylesheet" type="text/css" href="../views/adddriver.css">
    <script src="../controllers/add_rider_js.js"></script>
</head>
<body>
    <div class="container">
        <h1>Add Rider</h1>
        <form action="../controllers/add_rider_controller.php" method="post" onsubmit="return validate()" novalidate>
            <fieldset>
                <legend>Rider Information</legend>
                <table>
                    <tr>
                        <td><label for="name">Name:</label></td>
                        <td><input type="text" id="name" name="name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>"></td>
                        <td><span class="error" id="nameError">
                                <?php echo isset($_SESSION['nameError']) ? $_SESSION['nameError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" id="email" name="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>"></td>
                        <td><span class="error" id="emailError">
                                <?php echo isset($_SESSION['emailError']) ? $_SESSION['emailError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="phone">Phone:</label></td>
                        <td><input type="text" id="phone" name="phone" value="<?php echo isset($_SESSION['phone']) ? $_SESSION['phone'] : ''; ?>"></td>
                        <td><span class="error" id="phoneError">
                                <?php echo isset($_SESSION['phoneError']) ? $_SESSION['phoneError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="dob">Date of Birth:</label></td>
                        <td><input type="date" id="dob" name="dob" value="<?php echo isset($_SESSION['dob']) ? $_SESSION['dob'] : ''; ?>"></td>
                        <td><span class="error" id="dobError">
                                <?php echo isset($_SESSION['dobError']) ? $_SESSION['dobError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="gender">Gender:</label></td>
                        <td>
                            <select id="gender" name="gender">
                                <option value="">Select Gender</option>
                                <option value="male" <?php echo (isset($_SESSION['gender']) && $_SESSION['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?php echo (isset($_SESSION['gender']) && $_SESSION['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                                <option value="other" <?php echo (isset($_SESSION['gender']) && $_SESSION['gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </td>
                        <td><span class="error" id="genderError">
                                <?php echo isset($_SESSION['genderError']) ? $_SESSION['genderError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="address">Address:</label></td>
                        <td><textarea id="address" name="address"><?php echo isset($_SESSION['address']) ? $_SESSION['address'] : ''; ?></textarea></td>
                        <td><span class="error" id="addressError">
                                <?php echo isset($_SESSION['addressError']) ? $_SESSION['addressError'] : ''; ?>
                            </span></td>
                    </tr>
                </table>
            </fieldset>
            <br>
            <input type="submit" value="Add Rider">
        </form>

        <?php
        if (isset($_SESSION['successMessage']) && !empty($_SESSION['successMessage'])) {
            echo "<p class='success'>{$_SESSION['successMessage']}</p>";
            unset($_SESSION['successMessage']);
        }
        ?>
        <br>
        <a href="../controllers/show_rider_controller.php">Show Riders</a>
        <br>
        <br>
        <a href="../views/dashboard.php">Back to Admin Dashboard</a>
    </div>
</body>
</html>