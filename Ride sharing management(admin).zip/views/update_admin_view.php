<?php
include_once "../views/header1.php"; 

$admins= isset($_SESSION['admins']) ? $_SESSION['admins'] : [];
$selectedAdmin = isset($_SESSION['selectedAdmin']) ? $_SESSION['selectedAdmin'] : [];
$updateSuccess = isset($_SESSION['updateSuccess']) ? $_SESSION['updateSuccess'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Admin</title>
    <link rel="stylesheet" type="text/css" href="../views/driver_update.css">
    <script src="../controllers/update_admin_js.js" defer></script>
</head>

<body>
    <div class="container">
        <h1>Update/Delete Admin</h1>
        <div id="demo"></div>

        <?php if (!$updateSuccess): ?>
            <table class="rider-table">
                <tr>
                    <th>Admin ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Role</th>
                  
                    <th>Action(Select,Delete)</th>
                </tr>
                <?php foreach ($admins as $admin): ?>
                    <tr>
                        <td><?php echo $admin['admin_id']; ?></td>
                        <td><?php echo $admin['name']; ?></td>
                        <td><?php echo $admin['email']; ?></td>
                        <td><?php echo $admin['username']; ?></td>
                        <td><?php echo $admin['password']; ?></td>
                        <td><?php echo $admin['role']; ?></td>
                      
                        <td>
    <form method="POST" action="../controllers/update_admin_controller.php" style="display: inline;">
        <input type="hidden" name="admin_id" value="<?php echo $admin['admin_id']; ?>">
        <input type="submit" name="select_admin" value="Select" style="display: inline; margin-right: 5px;">
    </form>
    <form method="POST" action="../controllers/update_admin_controller.php" style="display: inline;">
        <input type="hidden" name="admin_id" value="<?php echo $admin['admin_id']; ?>">
        <input type="submit" name="delete_admin" value="Delete" style="display: inline;">
    </form>
</td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <?php if ($selectedAdmin !== null && !$updateSuccess): ?>
            <form method="post" action="../controllers/update_admin_controller.php" autocomplete="off" novalidate onsubmit="return isValidForm();">
                <fieldset>
                    <legend>Admin Information</legend>
                    <input type="hidden" id="admin_id" name="admin_id" value="<?php echo $selectedAdmin['admin_id']; ?>" readonly>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($selectedAdmin['name']) ? $selectedAdmin['name'] : ''; ?>">
                    <span class="error" id="nameError"></span>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($selectedAdmin['email']) ? $selectedAdmin['email'] : ''; ?>">
                    <span class="error" id="emailError"></span>

                    <label for="username">User Name:</label>
                    <input type="text" id="username" name="username" value="<?php echo isset($selectedAdmin['username']) ? $selectedAdmin['username'] : ''; ?>">
                    <span class="error" id="usernameError"></span>

                    
                    <label for="role">Role:</label>
                    <select id="role" name="role">
                        <option value="Cat.1" <?php echo(isset($selectedAdmin['role']) && $selectedAdmin['role'] == 'Cat.1') ? 'selected' : ''; ?>>Admin(Cat.1)</option>
                        <option value="Cat.2" <?php echo (isset($selectedAdmin['role']) && $selectedAdmin['role'] == 'Cat.2') ? 'selected' : ''; ?>>Admin(Cat.2)</option>
                     </select>
                    <span class="error" id="roleError"></span>

                    
                </fieldset>

                <div id="error-container" class="error-container"></div>

                <input type="submit" name="update_admin" value="Update Admin">
            </form>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['deleteMessage'])) {
            $deleteMessage = $_SESSION['deleteMessage'];
            unset($_SESSION['deleteMessage']);
            $updateSuccess=false;
            unset($_SESSION['updateSuccess']);
            echo '<p class="success">' . $deleteMessage . '!</p>';
        }

        if ($updateSuccess) {
            unset($_SESSION['updateSuccess']);
            unset($_SESSION['selectedAdmin']);
            echo '<p class="success">Admin updated successfully!</p>';
        }
        ?>

        <a href="../controllers/show_admin_controller.php">Show Admins</a>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>

<?php include_once "../views/footer.php"; ?>