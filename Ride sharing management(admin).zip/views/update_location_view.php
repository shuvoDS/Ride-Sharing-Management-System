<?php include_once "../views/header1.php"; 
$locations = isset($_SESSION['locations'])?$_SESSION['locations']:[];
$selectedLocation=isset($_SESSION['selectedLocation']) ? $_SESSION['selectedLocation']: [];
$updateSuccess=isset($_SESSION['updateSuccess']) ? $_SESSION['updateSuccess']: [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Route</title>
    <link rel="stylesheet" type="text/css" href="../views/driver_update.css">
	 <script src="../controllers/update_location.js" defer></script>
</head>

<body>
    <div class="container">
        <h1>Update/Delete Route</h1>
        <div id="demo"></div>

        <?php if (!$updateSuccess): ?>
            <table class="driver-table">
                <tr>
                    <th>Route ID</th>
                    <th>Starting Point</th>
                    <th>Destination</th>
                    <th>Action(Select,Delete)</th>
					
                </tr>
                <?php foreach ($locations as $location): ?>
                    <tr>
                        <td>
                            <?php echo $location['id']; ?>
                        </td>
                        <td>
                            <?php echo $location['starting_point']; ?>
                        </td>
                        <td>
                            <?php echo $location['destination']; ?>
                       
                       <td>
    <form method="POST" action="../controllers/update_location_controller.php" style="display: inline;">
        <input type="hidden" name="id" value="<?php echo $location['id']; ?>">
        <input type="submit" name="select_location" value="Select" style="display: inline; margin-right: 5px;">
    </form>
    <form method="POST" action="../controllers/update_location_controller.php" style="display: inline;">
        <input type="hidden" name="id" value="<?php echo $location['id']; ?>">
        <input type="submit" name="delete_location" value="Delete" style="display: inline;">
    </form>
                        </td>
			
			
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <?php if ($selectedLocation !== null && !$updateSuccess): ?>
            <form method="post" action="../controllers/update_location_controller.php"  autocomplete="off" novalidate onsubmit="return isValidForm();">
                <fieldset>
                    <legend>Route Information</legend>
                    <input type="hidden" id="id" name="id" value="<?php echo $selectedLocation['id']; ?>" readonly>

                    <label for="starting_point">Starting Point:</label>
                    <input type="text" id="starting_point" name="starting_point" value="<?php echo isset($selectedLocation['starting_point']) ? $selectedLocation['starting_point'] : ''; ?>">
                    <span class="error" id="startingError"></span>
                    <label for="destination">Destination:</label>
                    <input type="text" id="destination" name="destination" value="<?php echo isset($selectedLocation['destination']) ? $selectedLocation['destination'] : '';?>">
                    <span class="error" id="destinationError"></span>
                    
                </fieldset>

                <div id="error-container" class="error-container"></div>

                <input type="submit" name="update_location" value="Update Location">
            </form>
        <?php endif; ?>

        
		<?php 
            if (isset($_SESSION['deleteMessage'])) {
				 $deleteMessage = $_SESSION['deleteMessage'];
				 unset($_SESSION['deleteMessage']);
				 $updateSuccess=false;
				 unset($_SESSION['updateSuccess']);
                 echo '<p class="success">' . $deleteMessage . '!</p>';
				 
		 }?>
		 
		 <?php
		     
				 if ($updateSuccess) {
             unset($_SESSION['updateSuccess']);
			 unset($_SESSION['selectedLocation']);
             echo '<p class="success">Route updated successfully!</p>';
			 }
			 
        ?>


        <a href="../controllers/show_location_controller.php">Show Routes</a>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>

<?php include_once "../views/footer.php"; ?>
