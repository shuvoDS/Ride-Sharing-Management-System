<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
	<link rel="stylesheet" type="text/css" href="home.css">
    
</head>

<body>

    <div class="header">
        <h1>Ride Sharing Management - Admin Panel</h1>
        <h2>Home</h2>
    </div>

    <div class="topnav">
        <a href="../views/register_view.php">Register</a>
        <a href="../views/login_view.php" style="float:right">Login</a>
    </div>

    <div class="row">
        <div class="leftcolumn">
            <div class="card">
                <h2>About Us</h2>
                <h5>Description, April 10, 2024</h5>
                <p>Welcome to Ride Sharing Management, your go-to platform for managing ride-sharing services. We offer
                    a range of features and tools to make ride-sharing efficient and convenient for both drivers and
                    riders.</p>
            </div>

        </div>
        <div class="rightcolumn">


            <div class="card">
                <h3>Follow Us</h3>
                <p>ride@gmail.com</p>
            </div>
        </div>
    </div>

   

</body>

</html>
<?php include_once "footer.php"; ?>