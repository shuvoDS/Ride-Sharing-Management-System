<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <link rel="stylesheet" type="text/css" href="registration.css">
    <script src="../controllers/register_js.js"></script> 
</head>
<body>
    <header>
        <center><h1>Ride Sharing Management - Admin Panel</h1></center>
    </header>

    <div>
        <form action="../controllers/register_controller.php" method="post" enctype="application/x-www-form-urlencoded" autocomplete="off" novalidate onsubmit="return validate();"> <!-- Add onsubmit attribute -->
            <table>
                <tr>
                    <td><label for="firstname">First Name:</label></td>
                    <td>
                        <input type="text" name="firstname" id="firstname" value="<?php echo isset($_SESSION['data']['firstname']) ? htmlspecialchars($_SESSION['data']['firstname']) : ''; ?>">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_firstname"></td></tr>

                <tr>
                    <td><label for="lastname">Last Name:</label></td>
                    <td>
                        <input type="text" name="lastname" id="lastname" value="<?php echo isset($_SESSION['data']['lastname']) ? htmlspecialchars($_SESSION['data']['lastname']) : ''; ?>">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_lastname"></td></tr>

                <tr>
                    <td><label for="securityquestion">Security Question:</label></td>
                    <td>
                        <select name="securityquestion" id="securityquestion">
                            <option value=''>Select a security question</option>
                            <?php
                            $questions = [
                                'What is your favorite color?',
                                'What is your birth place?',
                                'What is your mother name?'
                            ];
                            foreach ($questions as $question) {
                                $selected = isset($_SESSION['data']['securityQuestion']) && $_SESSION['data']['securityQuestion'] == $question ? 'selected' : '';
                                echo "<option value='$question' $selected>$question</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_securityquestion"></td></tr>

                <tr>
                    <td><label for="securityanswer">Security Answer:</label></td>
                    <td>
                        <input type="text" name="securityanswer" id="securityanswer" value="<?php echo isset($_SESSION['data']['securityAnswer']) ? htmlspecialchars($_SESSION['data']['securityAnswer']) : ''; ?>">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_securityanswer"></td></tr>

                <tr>
                    <td><label for="Email">Email:</label></td>
                    <td>
                        <input type="email" name="Email" id="Email" value="<?php echo isset($_SESSION['data']['email']) ? htmlspecialchars($_SESSION['data']['email']) : ''; ?>">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_email"></td></tr>

                <tr>
                    <td><label for="username">Username:</label></td>
                    <td>
                        <input type="text" name="username" id="username" value="<?php echo isset($_SESSION['data']['username']) ? htmlspecialchars($_SESSION['data']['username']) : ''; ?>">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_username"></td></tr>

                <tr>
                    <td><label for="password">Password:</label></td>
                    <td>
                        <input type="password" name="password" id="password">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_password"></td></tr>

                <tr>
                    <td><label for="confirmpassword">Confirm Password:</label></td>
                    <td>
                        <input type="password" name="confirmpassword" id="confirmpassword">
                    </td>
                </tr>
                <tr><td colspan="2" class="error" id="error_confirmpassword"></td></tr>
            </table>
            <div class="button">
                <button type="submit">Register</button>
            </div>
        </form>
        <p>Already have an account? <a href="../views/login_view.php">Log in here</a>.</p>
    </div>

    <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
        <div class="error-container">
            <ul>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <?php echo htmlspecialchars($error); ?><br>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</body>
</html>
