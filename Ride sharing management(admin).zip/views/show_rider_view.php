<?php 

include_once "../views/header1.php"; 



if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}



if (!isset($_SESSION['riders'])) {
    echo "No rider data available.";
    exit();
}

$riderData = $_SESSION['riders'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Riders</title>
    <link rel="stylesheet" type="text/css" href="show_rider.css">
	<script type="text/javascript" src="show_rider.js"></script> 
    
</head>
<body>
    <div class="container">
        <h1>Show Riders</h1>
        <table border="1">
            <tr>
                <th>Rider ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Present Address</th>
            </tr>
            <?php
            foreach ($riderData as $rider) {
                echo "<tr>";
                echo "<td>{$rider['rider_id']}</td>";
                echo "<td>{$rider['name']}</td>";
                echo "<td>{$rider['email']}</td>";
                echo "<td>{$rider['phone']}</td>";
                echo "<td>{$rider['dob']}</td>";
                echo "<td>{$rider['gender']}</td>";
                echo "<td>{$rider['address']}</td>";
                echo "</tr>";
            }
            ?>
        </table><br>
        <div style="text-align: left;"> 
           
            <form onsubmit="return getData();">
                <input type='text' id="name" name='name'>
                <button type='submit'>Search</button>
            </form>
			 <p id="i1">Search Info.</p>
        </div>
        <p><a href="../views/dashboard.php">Back to Admin Dashboard</a></p>
    </div>
</body>
</html>

<?php include_once "../views/footer.php"; ?>