<?php 
include_once "../views/header1.php";?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" type="text/css" href="profileUpdate.css">
	<script src="../controllers/profile_update_js.js"></script> 
</head>
<body>
    <div class="container">
        <header>
            <h1>Update Profile</h1>
        </header>
        <main>
            <?php if (!empty($_SESSION['message'])): ?>
                <p><?php echo $_SESSION['message']; ?></p>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            <form action="../controllers/profile_update_controller.php" method="post" onsubmit="return validate()">
                <input type="email" name="currentEmail" placeholder="Current Email" value="<?php echo isset($_SESSION['currentEmail']) ? htmlspecialchars($_SESSION['currentEmail']) : ''; ?>">
                <div class="error" id="error_currentEmail"></div><br><br>
                <input type="email" name="newEmail" placeholder="New Email" value="<?php echo isset($_SESSION['newEmail']) ? htmlspecialchars($_SESSION['newEmail']) : ''; ?>">
                <div class="error" id="error_newEmail"></div><br><br>
                <input type="text" name="firstName" placeholder="First Name" value="<?php echo isset($_SESSION['FirstName']) ? htmlspecialchars($_SESSION['FirstName']) : ''; ?>">
                <div class="error" id="error_firstName"></div><br><br>
                <input type="text" name="lastName" placeholder="Last Name" value="<?php echo isset($_SESSION['LastName']) ? htmlspecialchars($_SESSION['LastName']) : ''; ?>">
                <div class="error" id="error_lastName"></div><br><br>
                <button type="submit">Update Profile</button>
            </form>
        </main>
    </div>
</body>
</html>

<?php include_once "../views/footer.php"; ?>
