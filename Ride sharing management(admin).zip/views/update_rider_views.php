<?php
include_once "../views/header1.php"; 

$riders = isset($_SESSION['riders']) ? $_SESSION['riders'] : [];
$selectedRider = isset($_SESSION['selectedRider']) ? $_SESSION['selectedRider'] : [];
$updateSuccess = isset($_SESSION['updateSuccess']) ? $_SESSION['updateSuccess'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Rider</title>
    <link rel="stylesheet" type="text/css" href="../views/driver_update.css">
    <script src="../controllers/update_rider_js.js" defer></script>
</head>

<body>
    <div class="container">
        <h1>Update/Delete Rider</h1>
        <div id="demo"></div>

        <?php if (!$updateSuccess): ?>
            <table class="rider-table">
                <tr>
                    <th>Rider ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Action(Select,Delete)</th>
                </tr>
                <?php foreach ($riders as $rider): ?>
                    <tr>
                        <td><?php echo $rider['rider_id']; ?></td>
                        <td><?php echo $rider['name']; ?></td>
                        <td><?php echo $rider['email']; ?></td>
                        <td><?php echo $rider['phone']; ?></td>
                        <td><?php echo $rider['dob']; ?></td>
                        <td><?php echo $rider['gender']; ?></td>
                        <td><?php echo $rider['address']; ?></td>
                        <td>
    <form method="POST" action="../controllers/update_rider_controller.php" style="display: inline;">
        <input type="hidden" name="rider_id" value="<?php echo $rider['rider_id']; ?>">
        <input type="submit" name="select_rider" value="Select" style="display: inline; margin-right: 5px;">
    </form>
    <form method="POST" action="../controllers/update_rider_controller.php" style="display: inline;">
        <input type="hidden" name="rider_id" value="<?php echo $rider['rider_id']; ?>">
        <input type="submit" name="delete_rider" value="Delete" style="display: inline;">
    </form>
</td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <?php if ($selectedRider !== null && !$updateSuccess): ?>
            <form method="post" action="../controllers/update_rider_controller.php" autocomplete="off" novalidate onsubmit="return isValidForm();">
                <fieldset>
                    <legend>Rider Information</legend>
                    <input type="hidden" id="rider_id" name="rider_id" value="<?php echo $selectedRider['rider_id']; ?>" readonly>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($selectedRider['name']) ? $selectedRider['name'] : ''; ?>">
                    <span class="error" id="nameError"></span>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($selectedRider['email']) ? $selectedRider['email'] : ''; ?>">
                    <span class="error" id="emailError"></span>

                    <label for="phone">Phone:</label>
                    <input type="text" id="phone" name="phone" value="<?php echo isset($selectedRider['phone']) ? $selectedRider['phone'] : ''; ?>">
                    <span class="error" id="phoneError"></span>

                    <label for="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="dob" value="<?php echo isset($selectedRider['dob']) ? $selectedRider['dob'] : ''; ?>">
                    <span class="error" id="dobError"></span>

                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender">
                        <option value="Male" <?php echo(isset($selectedRider['gender']) && $selectedRider['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo (isset($selectedRider['gender']) && $selectedRider['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo (isset($selectedRider['gender']) && $selectedRider['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                    </select>
                    <span class="error" id="genderError"></span>

                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" value="<?php echo isset($selectedRider['address']) ? $selectedRider['address'] : ''; ?>">
                    <span class="error" id="addressError"></span>
                </fieldset>

                <div id="error-container" class="error-container"></div>

                <input type="submit" name="update_rider" value="Update Rider">
            </form>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['deleteMessage'])) {
            $deleteMessage = $_SESSION['deleteMessage'];
            unset($_SESSION['deleteMessage']);
            $updateSuccess=false;
            unset($_SESSION['updateSuccess']);
            echo '<p class="success">' . $deleteMessage . '!</p>';
        }

        if ($updateSuccess) {
            unset($_SESSION['updateSuccess']);
            unset($_SESSION['selectedRider']);
            echo '<p class="success">Rider updated successfully!</p>';
        }
        ?>

        <a href="../controllers/show_rider_controller.php">Show Riders</a>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>

<?php include_once "../views/footer.php"; ?>