<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <link rel="stylesheet" type="text/css" href="logout.css">
</head>
<body>
    <header>
        <h1>Ride Sharing Management - Admin Panel</h1>
    </header>

    <div class="container">
        <fieldset>
            <legend>LOGGED OUT</legend>
            <h2>Thank you for using.</h2>
            <form method="post" action="../views/login_view.php">
                <input type="submit" value="Log In Again">
				
            </form>
        </fieldset>
    </div>

    <?php include_once "../views/footer.php"; ?>
	
</body>
</html>
