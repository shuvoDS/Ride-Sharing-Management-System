<?php
include_once "../views/header1.php"; 
$managers = isset($_SESSION['managers']) ? $_SESSION['managers'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Managers</title>
    <link rel="stylesheet" type="text/css" href="../views/show_admin_driver.css">
</head>

<body>
    <div class="container">
        <div id="fullInfo"></div>

        <div class="header">
            <h1>Show Managers</h1>
        </div>

        <table class="driAd-table">
            <tr>
                <th>Manager ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
               
            </tr>
            <?php foreach ($managers as $manager): ?>
                <tr>
                    <td><?php echo $manager['id']; ?></td>
                    <td><?php echo $manager['name']; ?></td>
                    <td><?php echo $manager['email']; ?></td>
                    <td><?php echo $manager['username']; ?></td>
                  
                </tr>
            <?php endforeach; ?>
        </table>

        <div id="noDataFound" style="display:none; text-align: center; margin-top: 10px;">
            No Data Found
        </div>

        <br>
        <a href="../views/dashboard.php">Back to Admin Dashboard</a>
    </div>
</body>

</html>
