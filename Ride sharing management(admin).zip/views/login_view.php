<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="login.css">
	<script src="../controllers/login_js.js"></script> 
</head>
<body>
    <center>
        <form action="../controllers/login_controller.php" method="post" autocomplete="off" novalidate onsubmit="return validate();">
            <fieldset>
                <legend>Login</legend>
                <table>
                    <tr>
                        <td>Email:</td>
                        <td><input type="email" name="email" id="email" value="<?php echo isset($_COOKIE['emailid']) ? $_COOKIE['emailid'] : (isset($_SESSION['email']) ? $_SESSION['email'] : ''); ?>"></td>
                    </tr>
                    <tr><td colspan="2" class="error" id="error_email"></td></tr>

                    <tr>
                        <td>Password:</td>
                        <td><input type="password" name="password" id="password" value="<?php echo isset($_COOKIE['password']) ? $_COOKIE['password'] : (isset($_SESSION['password']) ? $_SESSION['password'] : '');?>"></td>
                    </tr>
                    <tr><td colspan="2" class="error" id="error_password"></td></tr>

                    <tr>
                        <td><input type="checkbox" name="rememberMe" id="rememberMe"><label for="rememberMe">Remember me</label></td>
                    </tr>
                </table>
                <br>
                <?php if (!empty($_SESSION['emailErr'])): ?>
                    <p><?php echo $_SESSION['emailErr']; ?></p>
                <?php endif; ?>
                <?php if (!empty($_SESSION['passwordErr'])): ?>
                    <p><?php echo $_SESSION['passwordErr']; ?></p>
                <?php endif; ?>
                <?php if (!empty($_SESSION['Error'])): ?>
                    <p><?php echo $_SESSION['Error']; ?></p>
                <?php endif; ?>
            </fieldset>
            <br>
            <input type="submit" value="Login">
            <br>
            <br>
        </form>
        <form action="../views/forget_password_view.php">
            <input type="submit" value="Forget Password">
        </form>
        <p>Don't have an Account? <a href="../views/register_view.php">Click here</a> for Registration.</p>
    </center>

  
</body>
</html>
