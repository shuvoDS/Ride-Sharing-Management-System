<?php include_once "../views/header1.php"; ?>

<?php

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../views/dashBord.css">
</head>

<body>
    <header>
        <h1>Admin Dashboard</h1>
    </header>

    <main>
        <section id="drivers">
            <h2>Drivers</h2>
            <nav>
                <a href="../views/add_driver_view.php">Add Driver</a>
                <a href="../controllers/show_driver_controller.php">Show Drivers</a>
                <a href="../controllers/update_driver_controller.php">Update/Delete Driver</a>
            </nav>
        </section>
		<section id="riders">
            <h2>Riders</h2>
            <nav>
                <a href="../views/add_rider_view.php">Add Rider</a>
                <a href="../controllers/show_rider_controller.php">Show Rider</a>
                <a href="../controllers/update_rider_controller.php">Update/Delete Rider</a>
            </nav>
        </section>

        <section id="admins">
            <h2>Admins</h2>
            <nav>
                <a href="../views/add_admin_view.php">Add Admin</a>
                <a href="../controllers/show_admin_controller.php">Show Admin</a>
				<a href="../controllers/update_admin_controller.php">Update Admin</a>
            </nav>
        </section>
		
		<section id="CustomerSupportManager">
            <h2>Customer Support Manager</h2>
            <nav>
                <a href="../views/add_sm_view.php">Add Support Manager</a>
                <a href="../controllers/show_sm_controller.php">Show Support Manager</a>
				<a href="../controllers/update_sm_controller.php">Update Support Manager</a>
            </nav>
        </section>
		
		
		<section id="earnings">
            <h2>Earnings</h2>
            <nav>
                <a href="../controllers/show_earnings_controller.php">Show Earnings</a>
            </nav>
        </section>
		
		<section id="locations">
            <h2>Routes</h2>
            <nav>
                <a href="../views/add_location_view.php">Add Route</a>
				<a href="../controllers/show_location_controller.php">Show Route</a>
				<a href="../controllers/update_location_controller.php">Update/Delete</a>
				
            </nav>
        </section>
		
		
		
        
    </main>
</body>

</html>



<?php include_once "../views/footer.php"; ?>
