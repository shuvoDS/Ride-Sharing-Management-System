<?php
include_once "../views/header1.php"; 

$managers= isset($_SESSION['managers']) ? $_SESSION['managers'] : [];
$selectedManager = isset($_SESSION['selectedManager']) ? $_SESSION['selectedManager'] : [];
$updateSuccess = isset($_SESSION['updateSuccess']) ? $_SESSION['updateSuccess'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Support Manager</title>
    <link rel="stylesheet" type="text/css" href="../views/driver_update.css">
    <script src="../controllers/update_sm_js.js" defer></script>
</head>

<body>
    <div class="container">
        <h1>Update/Delete Support Manager</h1>
        <div id="demo"></div>

        <?php if (!$updateSuccess): ?>
            <table class="driver-table">
                <tr>
                    <th>Manager ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Name</th>
                    <th>Action(Select,Delete)</th>
                </tr>
                <?php foreach ($managers as $manager): ?>
                    <tr>
                        <td><?php echo $manager['id']; ?></td>
                        <td><?php echo $manager['name']; ?></td>
                        <td><?php echo $manager['email']; ?></td>
                        <td><?php echo $manager['username']; ?></td>
                        <td>
    <form method="POST" action="../controllers/update_sm_controller.php" style="display: inline;">
        <input type="hidden" name="id" value="<?php echo $manager['id']; ?>">
        <input type="submit" name="select_manager" value="Select" style="display: inline; margin-right: 5px;">
    </form>
    <form method="POST" action="../controllers/update_sm_controller.php" style="display: inline;">
        <input type="hidden" name="id" value="<?php echo $manager['id']; ?>">
        <input type="submit" name="delete_manager" value="Delete" style="display: inline;">
    </form>
</td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <?php if ($selectedManager !== null && !$updateSuccess): ?>
            <form method="post" action="../controllers/update_sm_controller.php" autocomplete="off" novalidate onsubmit="return isValidForm();">
                <fieldset>
                    <legend>Manager Information</legend>
                    <input type="hidden" id="id" name="id" value="<?php echo $selectedManager['id']; ?>" readonly>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($selectedManager['name']) ? $selectedManager['name'] : ''; ?>">
                    <span class="error" id="nameError"></span>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($selectedManager['email']) ? $selectedManager['email'] : ''; ?>">
                    <span class="error" id="emailError"></span>

                    <label for="username">User Name:</label>
                    <input type="text" id="username" name="username" value="<?php echo isset($selectedManager['username']) ? $selectedManager['username'] : ''; ?>">
                    <span class="error" id="usernameError"></span>

                 </fieldset>

                <div id="error-container" class="error-container"></div>

                <input type="submit" name="update_manager" value="Update Manager">
            </form>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['deleteMessage'])) {
            $deleteMessage = $_SESSION['deleteMessage'];
            unset($_SESSION['deleteMessage']);
            $updateSuccess=false;
            unset($_SESSION['updateSuccess']);
            echo '<p class="success">' . $deleteMessage . '!</p>';
        }

        if ($updateSuccess) {
            unset($_SESSION['updateSuccess']);
            unset($_SESSION['selectedManager']);
            echo '<p class="success">Manager updated successfully!</p>';
        }
        ?>

        <a href="../controllers/show_sm_controller.php">Show Support Managers</a>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>

<?php include_once "../views/footer.php"; ?>