<?php
include_once "../views/header1.php"; 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Support Manager</title>
    <link rel="stylesheet" type="text/css" href="../views/addDriver.css">
    <script src="../controllers/add_admin_js.js"></script> 
</head>

<body>
    <div class="container">
        <h1>Add Support Manager</h1>

        <form action="../controllers/add_sm_controller.php" method="post" onsubmit="return validate()" novalidate>
            <fieldset>
                <legend>Support Manager Information</legend>
                <table>
                    <tr>
                        <td><label for="name">Name:</label></td>
                        <td><input type="text" id="name" name="name" value="<?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?>"></td>
                        <td><span class="error" id="nameError">
                                <?php echo isset($_SESSION['nameError']) ? $_SESSION['nameError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" id="email" name="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>"></td>
                        <td><span class="error" id="emailError">
                                <?php echo isset($_SESSION['emailError']) ? $_SESSION['emailError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="username">Username:</label></td>
                        <td><input type="text" id="username" name="username" value="<?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?>"></td>
                        <td><span class="error" id="usernameError">
                                <?php echo isset($_SESSION['usernameError']) ? $_SESSION['usernameError'] : ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="password">Password:</label></td>
                        <td><input type="text" id="password" name="password" value="<?php echo isset($_SESSION['password']) ? $_SESSION['password'] : ''; ?>"></td>
                        <td><span class="error" id="passwordError">
                                <?php echo isset($_SESSION['passwordError']) ? $_SESSION['passwordError'] : ''; ?>
                            </span></td>
                    </tr>
                   
                </table>
            </fieldset>
            <br>
            <input type="submit" value="Add Support Manager">
        </form>

        <?php
        if (isset($_SESSION['successMessage']) && !empty($_SESSION['successMessage'])) {
            echo "<p class='success'>{$_SESSION['successMessage']}</p>";
            unset($_SESSION['successMessage']);
        }
        ?>
        <br>
        <a href="../views/dashboard.php">Back to Admin Dashboard</a>
    </div>
</body>

</html>
