<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="reset_password.css">
	<script src="../controllers/reset_password_js.js"></script> 
</head>

<body>
    <header>
        <h1>Ride Sharing Management - Admin Panel</h1>
    </header>

    <main>
        <center>
            <h2>Reset Password</h2>

            <?php if (isset($_SESSION['error'])): ?>
                <p>
                    <?php echo $_SESSION['error']; ?>
                </p>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['successMessage'])): ?>
                <p>
                    <?php echo $_SESSION['successMessage']; ?>
                    <br>
                    <br>
                    <a href="../views/login_view.php">Login</a>
                </p>
                <?php unset($_SESSION['successMessage']); ?>
            <?php else: ?>
                <form method="post" action="../controllers/reset_password_controller.php" autocomplete="off" novalidate onsubmit="return validate();">
                    <fieldset>
                        <legend>Reset Password</legend>
                        <table>
                            <tr>
                                <td><label for="new_password">New Password:</label></td>
                                <td><input type="password" id="new_password" name="new_password"></td>
                            </tr>
                            <tr><td colspan="2" class="error" id="error_new_password"></td></tr>
                            <tr>
                                <td><label for="confirm_password">Confirm Password:</label></td>
                                <td><input type="password" id="confirm_password" name="confirm_password"></td>
                            </tr>
                            <tr><td colspan="2" class="error" id="error_confirm_password"></td></tr>
                        </table>
                    </fieldset>
            </center>
            <br>
            <button type="submit">Reset Password</button>
            <br>
            </form>
        <?php endif; ?>

    </main>
    
    
</body>

</html>
