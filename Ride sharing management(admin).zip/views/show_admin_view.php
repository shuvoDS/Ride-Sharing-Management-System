<?php
include_once "../views/header1.php"; 
$admins = isset($_SESSION['admins']) ? $_SESSION['admins'] : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Admins</title>
    <link rel="stylesheet" type="text/css" href="../views/show_admin_driver.css">
</head>

<body>
    <div class="container">
        <div id="fullInfo"></div>

        <div class="header">
            <h1>Show Admins</h1>
        </div>

        <table class="driAd-table">
            <tr>
                <th>Admin ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Username</th>
                <th>Role</th>
            </tr>
            <?php foreach ($admins as $admin): ?>
                <tr>
                    <td><?php echo $admin['admin_id']; ?></td>
                    <td><?php echo $admin['name']; ?></td>
                    <td><?php echo $admin['email']; ?></td>
                    <td><?php echo $admin['username']; ?></td>
                    <td><?php echo $admin['role']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <div id="noDataFound" style="display:none; text-align: center; margin-top: 10px;">
            No Data Found
        </div>

        <br>
        <a href="../views/dashboard.php">Back to Admin Dashboard</a>
    </div>
</body>

</html>
