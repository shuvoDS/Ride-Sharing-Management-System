<?php include_once "../views/header1.php"; 

$drivers = isset($_SESSION['drivers']) ? $_SESSION['drivers'] : [];
$selectedDriver=isset($_SESSION['selectedDriver']) ? $_SESSION['selectedDriver']: [];
$updateSuccess=isset($_SESSION['updateSuccess']) ? $_SESSION['updateSuccess']: [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Driver</title>
    <link rel="stylesheet" type="text/css" href="../views/driver_update.css">
	 <script src="../controllers/update_driver_js.js" defer></script>
</head>

<body>
    <div class="container">
        <h1>Update/Delete Driver</h1>
        <div id="demo"></div>

        <?php if (!$updateSuccess): ?>
            <table class="driver-table">
                <tr>
                    <th>Driver ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>License Number</th>
                    <th>Action(Select,Delete)</th>
                </tr>
                <?php foreach ($drivers as $driver): ?>
                    <tr>
                        <td>
                            <?php echo $driver['driver_id']; ?>
                        </td>
                        <td>
                            <?php echo $driver['name']; ?>
                        </td>
                        <td>
                            <?php echo $driver['email']; ?>
                        </td>
                        <td>
                            <?php echo $driver['license']; ?>
                        <td>
    <form method="POST" action="../controllers/update_driver_controller.php" style="display: inline;">
        <input type="hidden" name="driver_id" value="<?php echo $driver['driver_id']; ?>">
        <input type="submit" name="select_driver" value="Select" style="display: inline; margin-right: 5px;">
    </form>
    <form method="POST" action="../controllers/update_driver_controller.php" style="display: inline;">
        <input type="hidden" name="driver_id" value="<?php echo $driver['driver_id']; ?>">
        <input type="submit" name="delete_driver" value="Delete" style="display: inline;">
    </form>
</td>
			
			
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <?php if ($selectedDriver !== null && !$updateSuccess): ?>
            <form method="post" action="../controllers/update_driver_controller.php"  autocomplete="off" novalidate onsubmit="return isValidForm();">
                <fieldset>
                    <legend>Driver Information</legend>
                    <input type="hidden" id="driver_id" name="driver_id" value="<?php echo $selectedDriver['driver_id']; ?>" readonly>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($selectedDriver['name']) ? $selectedDriver['name'] : ''; ?>">
                    <span class="error" id="nameError"></span>
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($selectedDriver['email']) ? $selectedDriver['email'] : '';?>">
                    <span class="error" id="emailError"></span>
                    <label for="license">License Number:</label>
                    <input type="text" id="license" name="license" value="<?php echo isset($selectedDriver['license']) ? $selectedDriver['license'] : ''; ?>">
					<span class="error" id="licenseError"></span>
                </fieldset>

                <div id="error-container" class="error-container"></div>

                <input type="submit" name="update_driver" value="Update Driver">
            </form>
        <?php endif; ?>

        
		<?php 
            if (isset($_SESSION['deleteMessage'])) {
				 $deleteMessage = $_SESSION['deleteMessage'];
				 unset($_SESSION['deleteMessage']);
				 $updateSuccess=false;
				 unset($_SESSION['updateSuccess']);
                 echo '<p class="success">' . $deleteMessage . '!</p>';
				 
		 }?>
		 
		 <?php
		     
				 if ($updateSuccess) {
             unset($_SESSION['updateSuccess']);
			 unset($_SESSION['selectedDriver']);
             echo '<p class="success">Driver updated successfully!</p>';
			 }
			 
        ?>


        <a href="../controllers/show_driver_controller.php">Show Drivers</a>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>

</html>

<?php include_once "../views/footer.php"; ?>
