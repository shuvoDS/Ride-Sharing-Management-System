<?php 

include_once "../views/header1.php"; 

if (!isset($_SESSION['drivers'])) {
    echo "No driver data available.";
    exit();
}

$driverData = $_SESSION['drivers'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Drivers</title>
    <link rel="stylesheet" type="text/css" href="show_rider.css">
	<script type="text/javascript" src="show_driver.js"></script> 
    
</head>
<body>
    <div class="container">
        <h1>Show Drivers</h1>
        <table border="1">
            <tr>
                <th>Driver ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>License</th>
               
            </tr>
            <?php
            foreach ($driverData as $driver) {
                echo "<tr>";
                echo "<td>{$driver['driver_id']}</td>";
                echo "<td>{$driver['name']}</td>";
                echo "<td>{$driver['email']}</td>";
                echo "<td>{$driver['license']}</td>";
               
                echo "</tr>";
            }
            ?>
        </table><br>
        <div style="text-align: left;"> 
           
            <form onsubmit="return getData();">
                <input type='text' id="name" name='name'>
                <button type='submit'>Search</button>
            </form>
			 <p id="i1">Search Info.</p>
        </div>
        <p><a href="../views/dashboard.php">Back to Admin Dashboard</a></p>
    </div>
</body>
</html>

<?php include_once "../views/footer.php"; ?>