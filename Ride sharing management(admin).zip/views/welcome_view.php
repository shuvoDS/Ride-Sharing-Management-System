<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="welcome.css">
</head>
<body class="body">
    <?php
    
    include_once "../views/header1.php";
    ?>

    <center>
        <div>
            <h2>Home Page</h2>
            <?php
            // Fetch sanitized session data
            $first_name = $_SESSION['displayFirstName'] ?? '';
            $last_name = $_SESSION['displayLastName'] ?? '';
            ?>
            <?php if (!empty($first_name) && !empty($last_name)): ?>
                <p>Welcome, <strong><?php echo htmlspecialchars($last_name) . ', ' . htmlspecialchars($first_name); ?></strong></p>
                <p>This is the home page.</p>
            <?php else: ?>
                <p>Welcome to the home page.</p>
            <?php endif; ?>
        </div>
    </center>

    <?php include_once "../views/footer.php"; ?>
</body>
</html>
