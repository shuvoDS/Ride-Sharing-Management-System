<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="forget_password.css">
	<script src="../controllers/forget_password_js.js"></script> 
</head>
<body>
    <header>
        <h1>Ride Sharing Management - Admin Panel</h1>
    </header>
    <main>
        <center>
            <h2>Forgot Password</h2>
            <?php
            session_start(); // Access the session variables

            $error = $_SESSION['messages']['error'] ?? '';
            $successMessage = $_SESSION['messages']['success'] ?? '';
            $formData = $_SESSION['form_data'] ?? [];
            $userData = $_SESSION['user_data'] ?? [];

            if (!empty($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>

            <form method="post" action="../controllers/forget_password_controller.php" autocomplete="off" novalidate onsubmit="return validate();">
                <fieldset>
                    <legend>Reset Password</legend>
                    <table>
                        <tr>
                            <td><label for="Username">Username:</label></td>
                            <td><input type="text" id="Username" name="Username" value="<?php echo htmlspecialchars($formData['Username'] ?? ''); ?>"></td>
                        </tr>
                        <tr><td colspan="2" class="error" id="error_username"></td></tr>

                        <tr>
                            <td><label for="securityQuestion">Security Question:</label></td>
                            <td>
                                <select id="securityQuestion" name="securityQuestion">
                                    <option value="" <?php echo empty($formData['securityQuestion']) ? 'selected' : ''; ?>>Select a security question</option>
                                    <option value="What is your favorite color?" <?php echo (isset($formData['securityQuestion']) && $formData['securityQuestion'] === "What is your favorite color?") ? 'selected' : ''; ?>>What is your favorite color?</option>
                                    <option value="What is your birth place?" <?php echo (isset($formData['securityQuestion']) && $formData['securityQuestion'] === "What is your birth place?") ? 'selected' : ''; ?>>What is your birth place?</option>
                                    <option value="What is your mother name?" <?php echo (isset($formData['securityQuestion']) && $formData['securityQuestion'] === "What is your mother name?") ? 'selected' : ''; ?>>What is your mother name?</option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td><label for="securityAnswer">Security Answer:</label></td>
                            <td><input type="text" id="securityAnswer" name="securityAnswer" value="<?php echo htmlspecialchars($formData['securityAnswer'] ?? ''); ?>"></td>
                        </tr>
                        <tr><td colspan="2" class="error" id="error_securityAnswer"></td></tr>
                    </table>
                    <br>
                    <button type="submit">Submit</button>
                </fieldset>
            </form>

            <?php if (!empty($successMessage) && !empty($userData)): ?>
                <p style="color: green;"><?php echo $successMessage; ?></p>
                <table border="1">
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                    </tr>
                    <tr>
                        <td><?php echo htmlspecialchars($userData['username']); ?></td>
                        <td><?php echo htmlspecialchars($userData['email']); ?></td>
                    </tr>
                </table>
                <p><a href="../views/reset_password_view.php">Reset Password</a></p>
            <?php endif; ?>
        </center>
    </main>

    
</body>
</html>
