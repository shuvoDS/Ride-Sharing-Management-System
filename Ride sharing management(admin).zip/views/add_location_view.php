
<?php include_once "../views/header1.php"; ?>
<?php

if (!isset($_SESSION['adminLogin']) || $_SESSION['adminLogin'] !== true) {
    header("Location: ../views/login_view.php");
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Location</title>
    <link rel="stylesheet" type="text/css" href="../views/add_location.css">
    <script src="../controllers/addlocation.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Add Location</h1>

        <form method="post" action="../controllers/add_location_controller.php" autocomplete="off" novalidate onsubmit="return isValidLocationForm();">
            <fieldset>
                <legend>Location Information</legend>
                <table>
                    <tr>
                        <td><label for="starting_point">Starting Point:</label></td>
                        <td><input type="text" id="starting_point" name="starting_point"></td>
                        <td><span class="error" id="startingPointError">
                                <?php echo $_SESSION['startingPointError'] ?? ''; ?>
                            </span></td>
                    </tr>
                    <tr>
                        <td><label for="destination">Destination:</label></td>
                        <td><input type="text" id="destination" name="destination"></td>
                        <td><span class="error" id="destinationError">
                                <?php echo $_SESSION['destinationError'] ?? ''; ?>
                            </span></td>
                    </tr>
                </table>
                <?php
                if (isset($_SESSION['successMessage'])) {
                    echo "<p class='success'>" . $_SESSION['successMessage'] . "</p>";
                    if (isset($_SESSION['mapsLink'])) {
                        echo "<p><a href=\"" . $_SESSION['mapsLink'] . "\" target=\"_blank\">View Route on Google Maps</a></p>";
                    }
                }
                unset($_SESSION['successMessage']);
                unset($_SESSION['mapsLink']);
                unset($_SESSION['startingPointError']);
                unset($_SESSION['destinationError']);
                ?>
            </fieldset>

            <button type="submit">Create Location</button>
            <br>

            <a href="../views/show_location_controller.php" target="_blank">Show Locations</a>
            <a href="../views/dashboard.php">Back to Admin dashboard</a>
        </form>
    </div>
</body>
</html>