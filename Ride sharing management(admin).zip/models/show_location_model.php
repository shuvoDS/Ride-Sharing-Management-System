<?php

function getLocations() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM location";
    $stmt = $con->prepare($sql);
    $locations = [];

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $locations[] = $row;
            }
            mysqli_free_result($result);
        }
        $stmt->close();
    } else {
        die("Prepared statement error: " . $con->error);
    }

    mysqli_close($con);
    return $locations;
}

function generateGoogleMapsLink($startingPoint, $destination) {
    $encodedStartingPoint = urlencode($startingPoint);
    $encodedDestination = urlencode($destination);
    return "https://www.google.com/maps?q=$encodedStartingPoint+to+$encodedDestination";
}
?>