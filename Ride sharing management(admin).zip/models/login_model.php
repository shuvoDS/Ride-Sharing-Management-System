<?php
// Handles the database connection and user credential check

function get_db_connection() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
    return $con;
}

function check_user_credentials($email, $password) {
    $con = get_db_connection();
    $sql = "SELECT * FROM reg WHERE email = ? AND password = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $con->close();
    return $user;
}
?>
