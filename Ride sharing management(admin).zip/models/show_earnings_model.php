<?php
function getTotalEarningsPerDriver() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb'); 
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT driver_id,name, year, SUM(earnings) as total_earnings FROM earning_report GROUP BY driver_id,name, year";
    $stmt = $con->prepare($sql);

    $earningsData = array();
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $earningsData[] = $row;
            }
        }
    } else {
        die("Prepared statement error: " . $con->error);
    }
    mysqli_close($con);
    return $earningsData;
}
?>