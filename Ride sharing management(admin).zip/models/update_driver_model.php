<?php
function getAllDrivers()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM driver";
    $result = mysqli_query($con, $sql);
    $drivers = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($con);

    return $drivers;
}

function getDriverById($driverId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM driver WHERE driver_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $driverId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $selectedDriver = $result->fetch_assoc();
        $stmt->close();
        mysqli_close($con);
        return $selectedDriver;
    } else {
        echo "Error fetching driver: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return null;
    }
}

function updateDriver($updatedName, $updatedEmail, $updatedLicense, $driverId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE driver SET name = ?, email = ?, license = ? WHERE driver_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sssi", $updatedName, $updatedEmail, $updatedLicense, $driverId);

    if ($stmt->execute()) {
        $stmt->close();
        mysqli_close($con);
        return true;
    } else {
        echo "Error updating driver: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return false;
    }
}

function deleteDriver($driverId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM driver WHERE driver_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $driverId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $message = "Driver deleted successfully.";
        } else {
            $message = "No driver found with the specified ID.";
        }
        $stmt->close();
        mysqli_close($con);
        return $message;
    } else {
        echo "Error deleting driver: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return "Deletion is not successful.";
    }
}
?>