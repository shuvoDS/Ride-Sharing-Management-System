<?php
function addDriver($name, $email, $license)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        return "Database connection failed: " . mysqli_connect_error();
    }

    $sql = "INSERT INTO driver (name, email, license) VALUES (?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sss", $name, $email, $license);

    if ($stmt->execute()) {
        $message = "Driver added successfully!";
    } else {
        $message = "Error adding driver: " . $con->error;
    }

    $stmt->close();
    $con->close();

    return $message;
}
?>
