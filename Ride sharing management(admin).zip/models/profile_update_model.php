<?php

function dbConnect() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    return $con;
}

function updateProfile($currentEmail, $newEmail, $firstName, $lastName) {
    $con = dbConnect();
    $sql = "UPDATE reg SET email = ?, firstName = ?, lastName = ? WHERE email = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 'ssss', $newEmail, $firstName, $lastName, $currentEmail);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($con);
    return $result;
}

function check_user_credentials($email) {
    $con = dbConnect();
    $sql = "SELECT * FROM reg WHERE Email = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $con->close();
    return $user;
}
?>
