<?php
function getManagers()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $admins = [];
    $sql = "SELECT id, name, email, username FROM supportmanager";

    $stmt = $con->prepare($sql);

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $managers[] = [
                    "id" => $row["id"],
                    "name" => $row["name"],
                    "email" => $row["email"],
                    "username" => $row["username"],
                   
                ];
            }
        }
        $stmt->close();
    } else {
        die("Database error: " . $con->error);
    }

    $con->close();

    return $managers;
}
?>
