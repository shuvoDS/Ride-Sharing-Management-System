<?php
function connectToDatabase() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    return $con; 
}

function getUserByEmail($con, $email) {
    $stmt = mysqli_prepare($con, "SELECT password FROM reg WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}

function updatePassword($con, $newPassword, $email) {
    $stmt = mysqli_prepare($con, "UPDATE reg SET password = ? WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "ss", $newPassword, $email);
    return mysqli_stmt_execute($stmt);
}
?>
