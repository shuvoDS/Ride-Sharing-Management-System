<?php

function connectDatabase() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    return $con;
}

function insertLocation($startingPoint, $destination) {
    $con = connectDatabase();
    $startingPoint = mysqli_real_escape_string($con, $startingPoint);
    $destination = mysqli_real_escape_string($con, $destination);

    $sql = "INSERT INTO location (starting_point, destination) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ss", $startingPoint, $destination);

    $result = false;
    try {
        $stmt->execute();
        $result = true;
    } catch (Exception $e) {
        // Handle exception
    }
    $stmt->close();
    mysqli_close($con);

    return $result;
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>