<?php
    $driverName = $_POST['searchKey'];
	$servername = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "ridedb";

   
    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
    
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $sql = "SELECT* FROM rider WHERE name = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare statement failed: " . $conn->error);
    }

    
    $stmt->bind_param("s", $riderName);

   
    $stmt->execute();
    
  
    $result = $stmt->get_result();
    
    $arr1 = array();
    if ($result->num_rows > 0) {
       
        while ($row = $result->fetch_assoc()) {
            $arr1[] = $row;
        }
    }

   
    $stmt->close();

   
    $conn->close();

   
    echo json_encode($arr1);
?>
	

