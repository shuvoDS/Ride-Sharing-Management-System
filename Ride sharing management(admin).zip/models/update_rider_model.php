<?php
function getAllRiders()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM rider";
    $result = mysqli_query($con, $sql);
    $riders = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($con);

    return $riders;
}

function getRiderById($riderId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM rider WHERE rider_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $riderId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $selectedRider = $result->fetch_assoc();
        $stmt->close();
        mysqli_close($con);
        return $selectedRider;
    } else {
        echo "Error fetching rider: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return null;
    }
}

function updateRider($updatedName, $updatedEmail, $updatedPhone, $updatedDob, $updatedGender, $updatedAddress, $riderId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE rider SET name = ?, email = ?, phone = ?, dob = ?, gender = ?, address = ? WHERE rider_id = ?";
    $stmt = $con->prepare($sql);
    if (!$stmt) {
        echo "Error preparing statement: " . $con->error;
        mysqli_close($con);
        return false;
    }
    $stmt->bind_param("ssssssi", $updatedName, $updatedEmail, $updatedPhone, $updatedDob, $updatedGender, $updatedAddress, $riderId);

    if ($stmt->execute()) {
        $stmt->close();
        mysqli_close($con);
        return true;
    } else {
        echo "Error updating rider: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return false;
    }
}

function deleteRider($riderId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM rider WHERE rider_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $riderId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $message = "Rider deleted successfully.";
        } else {
            $message = "No rider found with the specified ID.";
        }
        $stmt->close();
        mysqli_close($con);
        return $message;
    } else {
        echo "Error deleting rider: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return "Deletion is not successful.";
    }
}
?>