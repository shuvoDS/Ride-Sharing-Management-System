<?php
function getAllLocations()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM location";
    $result = mysqli_query($con, $sql);
    $locations = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($con);

    return $locations;
}

function getLocationById($locationId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM location WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $locationId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $selectedLocation = $result->fetch_assoc();
        $stmt->close();
        mysqli_close($con);
        return $selectedLocation;
    } else {
        echo "Error fetching location: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return null;
    }
}

function updateLocation($updatedStartingPoint, $updatedDestination , $locationId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE location SET starting_point = ?, destination = ? WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssi",$updatedStartingPoint, $updatedDestination , $locationId );

    if ($stmt->execute()) {
        $stmt->close();
        mysqli_close($con);
        return true;
    } else {
        echo "Error updating location: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return false;
    }
}

function deleteLocation($locationId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM location WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $locationId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $message = "Route deleted successfully.";
        } else {
            $message = "No Route found with the specified ID.";
        }
        $stmt->close();
        mysqli_close($con);
        return $message;
    } else {
        echo "Error deleting Route: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return "Route is not successful.";
    }
}
?>