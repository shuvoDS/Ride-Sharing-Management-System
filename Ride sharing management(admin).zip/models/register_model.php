<?php
// models/user_model.php
function dbConnect() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    return $con;
}

function insertUser($data) {
    $con = dbConnect();
    $stmt = $con->prepare("INSERT INTO reg (firstname, lastname, email, securityQuestion, securityAnswer, username, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $data['firstname'], $data['lastname'], $data['email'], $data['securityQuestion'], $data['securityAnswer'], $data['username'], $data['password']);
    $stmt->execute();
    $result = !$stmt->errno;
    $stmt->close();
    $con->close();
    return $result;
}
?>
