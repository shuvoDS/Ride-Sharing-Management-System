<?php
function getAllManagers()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT id,name,email,username FROM supportmanager";
    $result = mysqli_query($con, $sql);
    $managers = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($con);

    return $managers;
}

function getManagerById($managerId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT name,email,username  FROM supportmanager WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $managerId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $selectedManager= $result->fetch_assoc();
        $stmt->close();
        mysqli_close($con);
        return $selectedManager;
    } else {
        echo "Error fetching Manager: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return null;
    }
}

function updateManager($updatedName, $updatedEmail, $updatedUsernme,$Id)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE supportmanager SET name = ?, email = ?, username= ? WHERE id = ?";
    $stmt = $con->prepare($sql);
    if (!$stmt) {
        echo "Error preparing statement: " . $con->error;
        mysqli_close($con);
        return false;
    }
    $stmt->bind_param("sssi", $updatedName, $updatedEmail, $updatedUsernme,$Id);

    if ($stmt->execute()) {
        $stmt->close();
        mysqli_close($con);
        return true;
    } else {
        echo "Error updating Manager: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return false;
    }
}

function deleteManager($managerId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM supportmanager WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $managerId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $message = "Manager deleted successfully.";
        } else {
            $message = "No manager found with the specified ID.";
        }
        $stmt->close();
        mysqli_close($con);
        return $message;
    } else {
        echo "Error deleting Manager: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return "Deletion is not successful.";
    }
}
?>