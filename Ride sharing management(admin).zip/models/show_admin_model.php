<?php
function getAdmins()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $admins = [];
    $sql = "SELECT admin_id, name, email, username, role FROM admin";

    $stmt = $con->prepare($sql);

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $admins[] = [
                    "admin_id" => $row["admin_id"],
                    "name" => $row["name"],
                    "email" => $row["email"],
                    "username" => $row["username"],
                    "role" => $row["role"]
                ];
            }
        }
        $stmt->close();
    } else {
        die("Database error: " . $con->error);
    }

    $con->close();

    return $admins;
}
?>
