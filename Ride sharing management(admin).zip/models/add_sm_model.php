<?php
function supportmanager($name, $email, $username, $password)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        return "Database connection failed: " . mysqli_connect_error();
    }

    
    

    $sql = "INSERT INTO supportmanager (name, email, username, password) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $username, $password);

    if ($stmt->execute()) {
        $message = "Manager added successfully!";
    } else {
        $message = "Error adding Manager: " . $con->error;
    }

    $stmt->close();
    $con->close();

    return $message;
}
?>
