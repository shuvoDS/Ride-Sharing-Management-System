<?php
function getAllAdmins()
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM admin";
    $result = mysqli_query($con, $sql);
    $admins = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_close($con);

    return $admins;
}

function getAdminById($adminId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT name,email,username,role  FROM admin WHERE admin_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $adminId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $selectedAdmin = $result->fetch_assoc();
        $stmt->close();
        mysqli_close($con);
        return $selectedAdmin;
    } else {
        echo "Error fetching admin: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return null;
    }
}

function updateAdmin($updatedName, $updatedEmail, $updatedUsernme, $updatedRole, $adminId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "UPDATE admin SET name = ?, email = ?, username= ?, role = ? WHERE admin_id = ?";
    $stmt = $con->prepare($sql);
    if (!$stmt) {
        echo "Error preparing statement: " . $con->error;
        mysqli_close($con);
        return false;
    }
    $stmt->bind_param("ssssi", $updatedName, $updatedEmail, $updatedUsernme, $updatedRole,$adminId);

    if ($stmt->execute()) {
        $stmt->close();
        mysqli_close($con);
        return true;
    } else {
        echo "Error updating admin: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return false;
    }
}

function deleteAdmin($adminId)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM admin WHERE admin_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $adminId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $message = "Admin deleted successfully.";
        } else {
            $message = "No Admin found with the specified ID.";
        }
        $stmt->close();
        mysqli_close($con);
        return $message;
    } else {
        echo "Error deleting Admin: " . $stmt->error;
        $stmt->close();
        mysqli_close($con);
        return "Deletion is not successful.";
    }
}
?>