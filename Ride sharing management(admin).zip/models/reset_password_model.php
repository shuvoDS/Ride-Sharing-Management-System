<?php
function resetPassword($username, $newPassword) {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    $stmt = $con->prepare('UPDATE reg SET password = ? WHERE username = ?');
    $stmt->bind_param('ss', $newPassword, $username);
    $success = $stmt->execute();

    $con->close();
    return $success;
}
?>
