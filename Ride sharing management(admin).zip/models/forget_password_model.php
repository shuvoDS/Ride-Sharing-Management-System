<?php
function connect_db() {
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
    return $con;
}

function check_credentials($username, $securityQuestion, $securityAnswer) {
    $con = connect_db();
    $stmt = $con->prepare('SELECT * FROM reg WHERE username = ? AND securityQuestion = ? AND securityAnswer = ?');
    $stmt->bind_param('sss', $username, $securityQuestion, $securityAnswer);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $con->close();
    return $user;
}
?>
