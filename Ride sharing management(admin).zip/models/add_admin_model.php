<?php
function addAdmin($name, $email, $username, $password, $role)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        return "Database connection failed: " . mysqli_connect_error();
    }

    
    

    $sql = "INSERT INTO admin (name, email, username, password, role) VALUES (?, ?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sssss", $name, $email, $username, $password, $role);

    if ($stmt->execute()) {
        $message = "Admin added successfully!";
    } else {
        $message = "Error adding admin: " . $con->error;
    }

    $stmt->close();
    $con->close();

    return $message;
}
?>
