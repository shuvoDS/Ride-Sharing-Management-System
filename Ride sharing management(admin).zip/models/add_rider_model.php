<?php
function addRider($name, $email, $phone, $dob, $gender, $address)
{
    $con = mysqli_connect('localhost', 'root', '', 'ridedb');
    if (!$con) {
        return "Database connection failed: " . mysqli_connect_error();
    }

    $sql = "INSERT INTO rider (name, email, phone, dob, gender, address) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssssss", $name, $email, $phone, $dob, $gender, $address);

    if ($stmt->execute()) {
        $message = "Rider added successfully!";
    } else {
        $message = "Error adding rider: " . $con->error;
    }

    $stmt->close();
    $con->close();

    return $message;
}
?>

